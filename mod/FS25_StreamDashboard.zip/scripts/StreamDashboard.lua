-- FS25 Stream & Companion by leluxo - v1.4.4.0 - telemetrie cote client + affichage dans le jeu
-- Lit les infos de la partie (vehicule, outils, outil a main, champ, meteo, argent...) et les ecrit
-- dans modSettings/FS25_StreamDashboard/data.json pour le dashboard (dossier "dashboard", server.py).

StreamDashboard = {}
StreamDashboard.UPDATE_INTERVAL_MS = 250
StreamDashboard.WRITE_INTERVAL_MS = 500
StreamDashboard.SPEED_SMOOTHING = 0.35
StreamDashboard.MAX_IMPLEMENT_DEPTH = 4

-- ---------------------------------------------------------------- JSON ----
local function jsonString(value)
    if value == nil then return '""' end
    value = tostring(value)
    value = value:gsub("\\", "\\\\"):gsub('"', '\\"')
                 :gsub("\r", "\\r"):gsub("\n", "\\n"):gsub("\t", "\\t")
    return '"' .. value .. '"'
end

local function jsonNumber(value)
    if type(value) ~= "number" or value ~= value or value == math.huge or value == -math.huge then
        return "null"
    end
    return string.format("%.3f", value)
end

-- Valeur JSON deja encodee (objets / tableaux imbriques).
local RAW = {}
local function raw(str) return setmetatable({ s = str }, RAW) end

local function jsonValue(v)
    local t = type(v)
    if t == "nil" then return "null" end
    if t == "boolean" then return v and "true" or "false" end
    if t == "number" then return jsonNumber(v) end
    if t == "string" then return jsonString(v) end
    if t == "table" and getmetatable(v) == RAW then return v.s end
    return "null"
end

local function jsonObject(tbl)
    local parts = {}
    for key, value in pairs(tbl) do
        table.insert(parts, jsonString(key) .. ":" .. jsonValue(value))
    end
    return "{" .. table.concat(parts, ",") .. "}"
end

local function normalizePath(path)
    if path == nil or path == "" then return nil end
    return (tostring(path):gsub("\\", "/"))
end

-- ------------------------------------------------------------ VEHICULES ----
local function getStoreItem(vehicle)
    if vehicle == nil or vehicle.configFileName == nil or g_storeManager == nil then
        return nil
    end
    local ok, item = pcall(g_storeManager.getItemByXMLFilename, g_storeManager, vehicle.configFileName)
    if ok then return item end
    return nil
end

local function getBrandTitle(storeItem)
    if storeItem == nil or storeItem.brandIndex == nil or g_brandManager == nil then
        return nil
    end
    local ok, brand = pcall(g_brandManager.getBrandByIndex, g_brandManager, storeItem.brandIndex)
    if ok and brand ~= nil and brand.title ~= nil and brand.name ~= "NONE" then
        return brand.title
    end
    return nil
end

local function getVehicleName(vehicle)
    if vehicle == nil then return "Aucun véhicule" end
    local name = nil
    if vehicle.getName ~= nil then
        local ok, value = pcall(vehicle.getName, vehicle)
        if ok then name = value end
    end
    if name == nil or name == "" then
        local storeItem = getStoreItem(vehicle)
        if storeItem ~= nil and storeItem.name ~= nil then name = storeItem.name end
    end
    if name == nil or name == "" then
        name = vehicle.typeName or vehicle.configFileName or "Véhicule"
    end
    name = tostring(name):gsub("^.*[/\\]", ""):gsub("%.xml$", "")
    return name
end

-- Chemin de l'image de boutique du vehicule : c'est la meme image que dans le magasin du jeu,
-- y compris pour les mods (chaque XML de vehicule declare son <storeData><image>).
local function getImagePath(vehicle, storeItem)
    local image = nil
    if storeItem ~= nil and storeItem.imageFilename ~= nil and storeItem.imageFilename ~= "" then
        image = storeItem.imageFilename
    end
    if image ~= nil and tostring(image):find("store_empty") then image = nil end   -- image vide du jeu (ex. lampe de poche)
    if image == nil and vehicle ~= nil and vehicle.getImageFilename ~= nil then
        local ok, value = pcall(vehicle.getImageFilename, vehicle)
        if ok and type(value) == "string" and value ~= "" then image = value end
    end
    return normalizePath(image)
end

local function getFuel(vehicle)
    if vehicle == nil or vehicle.getConsumerFillUnitIndex == nil or FillType == nil then
        return nil, nil
    end
    local ok, level, capacity = pcall(function()
        local index = vehicle:getConsumerFillUnitIndex(FillType.DIESEL)
        if index == nil then return nil, nil end
        return vehicle:getFillUnitFillLevel(index), vehicle:getFillUnitCapacity(index)
    end)
    if ok and type(level) == "number" and type(capacity) == "number" and capacity > 0 then
        return level, capacity
    end
    return nil, nil
end

local function getConditionPercent(vehicle)
    if vehicle == nil or vehicle.getDamageAmount == nil then return nil end
    local ok, damage = pcall(vehicle.getDamageAmount, vehicle)
    if ok and type(damage) == "number" then
        return math.max(0, math.min(100, (1 - damage) * 100))
    end
    return nil
end

-- Contenu des reservoirs (remorque, citerne, semoir, epandeur...) hors carburant & co.
local CONSUMER_NAMES = { "DIESEL", "DEF", "ELECTRICCHARGE", "METHANE", "AIR" }

local function isConsumerUnit(unit)
    if FillType == nil or unit.supportedFillTypes == nil then return false end
    local consumer = {}
    for _, name in ipairs(CONSUMER_NAMES) do
        if FillType[name] ~= nil then consumer[FillType[name]] = true end
    end
    local any = false
    for fillTypeIndex, supported in pairs(unit.supportedFillTypes) do
        if supported then
            any = true
            if not consumer[fillTypeIndex] then return false end
        end
    end
    return any
end

local function getFillTypeInfo(index)
    if index == nil or g_fillTypeManager == nil then return nil end
    local ok, fillType = pcall(g_fillTypeManager.getFillTypeByIndex, g_fillTypeManager, index)
    if ok then return fillType end
    return nil
end

-- Renvoie une liste de chaines JSON : {title, level, capacity, icon}
local function getFills(vehicle)
    local fills = {}
    local spec = vehicle ~= nil and vehicle.spec_fillUnit or nil
    if spec == nil or spec.fillUnits == nil then return fills end

    for index, unit in ipairs(spec.fillUnits) do
        pcall(function()
            if unit.showOnHud == false or isConsumerUnit(unit) then return end
            local capacity = vehicle:getFillUnitCapacity(index)
            if type(capacity) ~= "number" or capacity <= 0 or capacity > 1e9 then return end
            local level = vehicle:getFillUnitFillLevel(index) or 0
            local title, icon = nil, nil
            if level > 0.01 then
                local fillTypeIndex = vehicle:getFillUnitFillType(index)
                if fillTypeIndex ~= nil and (FillType == nil or fillTypeIndex ~= FillType.UNKNOWN) then
                    local fillType = getFillTypeInfo(fillTypeIndex)
                    if fillType ~= nil then
                        title = fillType.title
                        icon = normalizePath(fillType.hudOverlayFilename)
                    end
                end
            end
            table.insert(fills, jsonObject({
                title = title, level = level, capacity = capacity, icon = icon,
            }))
        end)
    end
    return fills
end

-- Etats du vehicule / des outils (voyants du dashboard).
-- Tout est optionnel : un etat que le jeu n'expose pas est simplement omis (le dashboard masque l'icone).
local function tryCall(obj, name, ...)
    if obj == nil or type(obj[name]) ~= "function" then return nil end
    local ok, value = pcall(obj[name], obj, ...)
    if ok then return value end
    return nil
end

local function asBool(value)
    if value == nil then return nil end
    if type(value) == "number" then return value ~= 0 end
    return value and true or false
end

local function firstCall(obj, names)
    for _, name in ipairs(names) do
        local value = tryCall(obj, name)
        if value ~= nil then return value end
    end
    return nil
end

local function getStatus(vehicle)
    local s = {}
    if vehicle == nil then return s end

    -- moteur
    pcall(function()
        local motor = tryCall(vehicle, "getIsMotorStarted")
        if motor == nil and vehicle.spec_motorized ~= nil then motor = vehicle.spec_motorized.isMotorStarted end
        s.engine = asBool(motor)
    end)

    -- feux, gyrophare, clignotants
    pcall(function()
        local spec = vehicle.spec_lights
        if spec == nil then return end
        local mask = firstCall(vehicle, { "getLightsTypesMask", "getLightsTypeMask" })
        if mask == nil then mask = spec.lightsTypesMask end
        if mask == nil then mask = spec.currentLightsTypesMask end
        if type(mask) == "number" then
            s.lightsMask = mask
            s.lights = mask ~= 0
            local function has(constName, default)
                local t = default
                if Lights ~= nil and type(Lights[constName]) == "number" then t = Lights[constName] end
                if bitAND == nil then return nil end
                return bitAND(mask, 2 ^ t) ~= 0
            end
            s.lightLow = has("LIGHT_TYPE_DEFAULT", 0)
            s.lightHigh = has("LIGHT_TYPE_HIGHBEAM", 3)
            s.lightWorkFront = has("LIGHT_TYPE_WORK_FRONT", 2)
            s.lightWorkBack = has("LIGHT_TYPE_WORK_BACK", 1)
        end
        local beacon = firstCall(vehicle, { "getBeaconLightsActive", "getAreBeaconLightsActive", "getIsBeaconLightActive" })
        if beacon == nil then beacon = spec.beaconLightsActive end
        if beacon == nil then beacon = spec.beaconActive end
        s.beacon = asBool(beacon)
        local turn = tryCall(vehicle, "getTurnLightState")
        if turn == nil then turn = spec.turnLightState end
        if type(turn) == "number" then
            s.turnState = turn
            local left = (Lights ~= nil and type(Lights.TURNLIGHT_LEFT) == "number") and Lights.TURNLIGHT_LEFT or 1
            local right = (Lights ~= nil and type(Lights.TURNLIGHT_RIGHT) == "number") and Lights.TURNLIGHT_RIGHT or 2
            local hazard = (Lights ~= nil and type(Lights.TURNLIGHT_HAZARD) == "number") and Lights.TURNLIGHT_HAZARD or 3
            s.turnLeft = (turn == left)
            s.turnRight = (turn == right)
            s.hazard = (turn == hazard)
        end
    end)

    -- frein a main (si le jeu l'expose)
    pcall(function()
        s.parkingBrake = asBool(firstCall(vehicle, { "getIsHandbrakeActive", "getIsParkingBrakeActive", "getParkingBrakeActive" }))
    end)

    -- regulateur de vitesse et marche arriere
    pcall(function()
        local drivable = vehicle.spec_drivable
        local state = tryCall(vehicle, "getCruiseControlState")
        if state == nil and drivable ~= nil and type(drivable.cruiseControl) == "table" then
            state = drivable.cruiseControl.state
        end
        if type(state) == "number" then
            local off = (Drivable ~= nil and type(Drivable.CRUISECONTROL_STATE_OFF) == "number") and Drivable.CRUISECONTROL_STATE_OFF or 0
            s.cruise = state ~= off
            s.cruiseState = state
            if s.cruise then
                local limit = tryCall(vehicle, "getCruiseControlSpeed")
                if type(limit) == "number" then s.cruiseSpeed = limit end
            end
        end
        local reverser = drivable ~= nil and drivable.reverserDirection or nil
        local moving = vehicle.movingDirection
        local speed = tryCall(vehicle, "getLastSpeed")
        if type(speed) ~= "number" then speed = 0 end
        if type(reverser) == "number" or type(moving) == "number" then
            s.reverse = (type(reverser) == "number" and reverser < 0)
                or (type(moving) == "number" and moving < 0 and speed > 0.5)
        end
    end)

    -- outils : releve/abaisse, en marche, deplie
    pcall(function()
        s.turnedOn = asBool(tryCall(vehicle, "getIsTurnedOn"))
        s.lowered = asBool(tryCall(vehicle, "getIsLowered", false))
        if tryCall(vehicle, "getAllowsLowering") == false then s.lowered = nil end
        local unfolded = tryCall(vehicle, "getIsUnfolded")
        if unfolded == nil then
            local folded = tryCall(vehicle, "getIsFolded")
            if folded ~= nil then unfolded = not asBool(folded) end
        end
        s.unfolded = asBool(unfolded)
    end)

    return s
end

local function describeVehicle(vehicle, withFills)
    local storeItem = getStoreItem(vehicle)
    local info = {
        name = getVehicleName(vehicle),
        brand = getBrandTitle(storeItem),
        image = getImagePath(vehicle, storeItem),
        xml = normalizePath(vehicle ~= nil and vehicle.configFileName or nil),
        mod = vehicle ~= nil and vehicle.customEnvironment or nil,
    }
    if withFills then
        info.fills = raw("[" .. table.concat(getFills(vehicle), ",") .. "]")
        info.status = raw(jsonObject(getStatus(vehicle)))
    end
    return info
end

local function collectImplements(vehicle, list, seen, depth)
    if vehicle == nil or depth > StreamDashboard.MAX_IMPLEMENT_DEPTH then return end

    local function add(attached)
        if attached == nil or attached == vehicle or seen[attached] then return end
        seen[attached] = true
        table.insert(list, describeVehicle(attached, true))
        -- Outils / remorques attaches a l'outil (ex. remorque derriere un epandeur).
        collectImplements(attached, list, seen, depth + 1)
    end

    if vehicle.getAttachedImplements ~= nil then
        local ok, attached = pcall(vehicle.getAttachedImplements, vehicle)
        if ok and type(attached) == "table" then
            for _, entry in pairs(attached) do
                add(entry.object or entry.vehicle or entry)
            end
        end
    end

    local spec = vehicle.spec_attacherJoints
    if spec ~= nil and spec.attachedImplements ~= nil then
        for _, entry in pairs(spec.attachedImplements) do
            add(entry.object or entry)
        end
    end
end

local function getRootPosition(vehicle)
    if vehicle == nil or vehicle.rootNode == nil or getWorldTranslation == nil then
        return nil
    end
    local ok, x, y, z = pcall(getWorldTranslation, vehicle.rootNode)
    if not ok or type(x) ~= "number" or type(z) ~= "number" then
        return nil
    end
    return x, z
end

local function getPlayerPosition()
    local node = nil
    if g_localPlayer ~= nil then node = g_localPlayer.rootNode end
    if node == nil and g_currentMission ~= nil and g_currentMission.player ~= nil then node = g_currentMission.player.rootNode end
    if node == nil or getWorldTranslation == nil then return nil end
    local ok, x, _, z = pcall(getWorldTranslation, node)
    if ok and type(x) == "number" and type(z) == "number" then return x, z end
    return nil
end

-- Vehicule reellement conduit par le joueur local (inchange depuis la v3).
local function getControlledVehicle(mission)
    if mission == nil then return nil end

    if mission.controlledVehicle ~= nil then
        return mission.controlledVehicle
    end

    local function fromPlayer(player)
        if player == nil then return nil end

        if type(player.getCurrentVehicle) == "function" then
            local ok, vehicle = pcall(player.getCurrentVehicle, player)
            if ok and vehicle ~= nil then return vehicle end
        end

        if player.currentVehicle ~= nil then return player.currentVehicle end
        if player.vehicle ~= nil then return player.vehicle end
        if player.getEnteredVehicle ~= nil and type(player.getEnteredVehicle) == "function" then
            local ok, vehicle = pcall(player.getEnteredVehicle, player)
            if ok and vehicle ~= nil then return vehicle end
        end
        return nil
    end

    local vehicle = fromPlayer(mission.player)
    if vehicle ~= nil then return vehicle end

    local playerSystem = mission.playerSystem
    if playerSystem ~= nil and type(playerSystem.getPlayerByUserId) == "function" then
        local userId = mission.playerUserId
        if userId == nil then userId = 0 end
        local ok, player = pcall(playerSystem.getPlayerByUserId, playerSystem, userId)
        if ok then
            vehicle = fromPlayer(player)
            if vehicle ~= nil then return vehicle end
        end
    end

    return nil
end

-- Outil a main tenu par le joueur a pied (tronconneuse, lampe torche...). L'API FS25 n'etant pas
-- documentee, on essaie plusieurs acces connus puis on cherche un objet "outil" dans le joueur.
-- Renvoie l'outil et le chemin trouve (pour le journal), ou nil.
local function looksLikeHandTool(obj)
    if type(obj) ~= "table" then return false end
    if HandTool ~= nil and type(obj.isa) == "function" then
        local ok, yes = pcall(obj.isa, obj, HandTool)
        if ok and yes then return true end
    end
    return type(obj.configFileName) == "string" and obj.configFileName ~= ""
end

-- Vrai outil (pas les "mains nues", que le jeu traite aussi comme un outil a main sans article de boutique)
local function isRealHandTool(obj)
    if not looksLikeHandTool(obj) then return false end
    local cfg = string.lower(tostring(obj.configFileName or ""))
    if cfg:find("[/\\]hands[/\\%.]") or cfg:find("^hands[/\\%.]") then return false end
    if string.lower(getVehicleName(obj)) == "hands" then return false end
    return getStoreItem(obj) ~= nil
end

local function getLocalPlayer(mission)
    if g_localPlayer ~= nil then return g_localPlayer end
    if mission ~= nil then return mission.player end
    return nil
end

local function getHeldHandTool(mission)
    local player = getLocalPlayer(mission)
    if player == nil then return nil end
    local holders = { { player, "player" } }
    if type(player.hands) == "table" then table.insert(holders, { player.hands, "player.hands" }) end
    local methods = { "getHeldHandTool", "getCurrentHandTool", "getEquippedHandTool", "getHandTool", "getCarriedHandTool" }
    local fields = { "heldHandTool", "currentHandTool", "currentHandtool", "equippedHandTool", "handTool", "currentTool", "carriedHandTool" }
    for _, h in ipairs(holders) do
        local obj, label = h[1], h[2]
        for _, m in ipairs(methods) do
            local v = tryCall(obj, m)
            if isRealHandTool(v) then return v, label .. ":" .. m .. "()" end
        end
        for _, f in ipairs(fields) do
            local v = rawget(obj, f)
            if v == nil then local ok, val = pcall(function() return obj[f] end); if ok then v = val end end
            if isRealHandTool(v) then return v, label .. "." .. f end
        end
    end
    -- repli : premier objet "outil a main" (classe HandTool) reference directement par le joueur ou ses mains
    if HandTool ~= nil then
        for _, h in ipairs(holders) do
            for k, v in pairs(h[1]) do
                if type(k) == "string" and type(v) == "table" and v ~= player and type(v.isa) == "function" then
                    local ok, yes = pcall(v.isa, v, HandTool)
                    if ok and yes and isRealHandTool(v) then return v, h[2] .. "." .. k .. " (scan)" end
                end
            end
        end
    end
    return nil
end

-- ------------------------------------------------------------ INFOS JEU ----
local function getWeatherName(weather)
    if weather == nil or weather.getCurrentWeatherType == nil or WeatherType == nil then
        return nil
    end
    local ok, current = pcall(weather.getCurrentWeatherType, weather)
    if not ok or current == nil then return nil end
    for key, value in pairs(WeatherType) do
        if value == current and type(key) == "string" then return key end
    end
    return nil
end

-- ------------------------------------------------------ PARTIE : METEO, TEMPS ----
local DAY_MS = 24 * 60 * 60 * 1000

local function weatherTypeName(value)
    if value == nil or WeatherType == nil then return nil end
    for key, v in pairs(WeatherType) do
        if v == value and type(key) == "string" then return key end
    end
    return nil
end

-- Previsions : le jeu ne documente pas l'API de prevision pour FS25. On interroge le type de temps a un
-- instant futur (getWeatherTypeAtTime), comme dans les versions precedentes ; tout est optionnel.
-- La temperature future n'est utilisee que si getTemperatureAtTime(maintenant) colle a la temperature actuelle.
local FORECAST_PLAIN = {}                                     -- dernieres previsions, en tables (bloc meteo du HUD)
local function getForecast(env)
    local items, tempOk = {}, false
    local plain = {}
    FORECAST_PLAIN = plain
    local weather = env ~= nil and env.weather or nil
    if weather == nil or type(env.currentDay) ~= "number" or type(env.dayTime) ~= "number" then return items, tempOk end

    local nowTemp = tryCall(weather, "getCurrentTemperature")
    local probe = tryCall(weather, "getTemperatureAtTime", env.dayTime)
    tempOk = type(nowTemp) == "number" and type(probe) == "number" and math.abs(nowTemp - probe) < 2

    local function add(day, dayTime)
        local name = weatherTypeName(tryCall(weather, "getWeatherTypeAtTime", day, dayTime))
        if name == nil then return end
        local item = {
            type = name,
            hours = math.floor(((day - env.currentDay) * DAY_MS + dayTime - env.dayTime) / 360000 + 0.5) / 10,
            dayOffset = day - env.currentDay,
        }
        if tempOk then
            local temp = tryCall(weather, "getTemperatureAtTime", dayTime)
            if type(temp) == "number" then item.temperature = temp end
        end
        table.insert(items, jsonObject(item))
        table.insert(plain, item)
    end

    for _, h in ipairs({ 3, 6, 12 }) do
        local t, d = env.dayTime + h * 3600000, env.currentDay
        while t >= DAY_MS do t = t - DAY_MS; d = d + 1 end
        add(d, t)
    end
    add(env.currentDay + 1, 14 * 3600000)
    add(env.currentDay + 2, 14 * 3600000)
    return items, tempOk
end

local function getGameInfo()
    local mission = g_currentMission
    local game = {}
    if mission == nil then return game end

    pcall(function()
        local env = mission.environment
        if env ~= nil then
            game.hour = env.currentHour
            game.minute = env.currentMinute
            game.day = env.currentDay or env.currentMonotonicDay
            if env.weather ~= nil then
                if env.weather.getCurrentTemperature ~= nil then
                    game.temperature = env.weather:getCurrentTemperature()
                end
                game.weather = getWeatherName(env.weather)
            end
        end
    end)

    -- mois (periode de saison), vitesse d'ecoulement du temps, previsions
    pcall(function()
        local env = mission.environment
        if env ~= nil then
            local period = env.currentVisualPeriod or env.currentPeriod
            if type(period) == "number" then game.period = period end
            if type(env.currentDayInPeriod) == "number" then game.dayInPeriod = env.currentDayInPeriod end
            local items, tempOk = getForecast(env)
            if #items > 0 then
                game.forecast = raw("[" .. table.concat(items, ",") .. "]")
                game.forecastTempOk = tempOk
            end
        end
        local scale = tryCall(mission, "getTimeScale")
        if type(scale) == "number" then game.timeScaleSrc = "getTimeScale"
        elseif mission.missionInfo ~= nil and type(mission.missionInfo.timeScale) == "number" then
            scale = mission.missionInfo.timeScale; game.timeScaleSrc = "missionInfo.timeScale"
        elseif env ~= nil and type(env.timeScale) == "number" then
            scale = env.timeScale; game.timeScaleSrc = "environment.timeScale"
        end
        if type(scale) == "number" then game.timeScale = scale end
    end)

    pcall(function()
        if mission.getMoney ~= nil then
            game.money = mission:getMoney()
        elseif g_farmManager ~= nil and mission.getFarmId ~= nil then
            local farm = g_farmManager:getFarmById(mission:getFarmId())
            if farm ~= nil then game.money = farm.money end
        end
    end)

    pcall(function()                                         -- ferme du joueur (mode compagnon : "mes champs")
        local fid = tryCall(mission, "getFarmId")
        if type(fid) == "number" then game.farmId = fid end
    end)

    pcall(function()
        local info = mission.missionInfo
        if info ~= nil then
            if type(info.playTime) == "number" then game.playHours = info.playTime / 60 end
            game.map = info.mapTitle or info.savegameName
        end
    end)

    return game
end

-- ----------------------------------------------------------------- CHAMP ----
-- Numero du champ, culture, croissance, fertilisation, chaux... a la position du vehicule (ou du joueur a pied).
-- Deux sources : (1) les donnees du propre panneau d'info de champ du jeu, captees au passage ;
-- (2) un calcul direct (FieldState) a la position. Tout est optionnel et garde par pcall.
local FIELD_STALE_MS = 2500
local FIELD_CAPTURE_EVERY_MS = 250

local function sortedKeys(t)
    local keys = {}
    for k in pairs(t) do
        if type(k) == "string" then table.insert(keys, k) end
    end
    table.sort(keys)
    return keys
end

-- Copie a plat des valeurs simples d'une table (et d'un niveau de sous-tables), pour decouvrir les champs reels.
local function snapshotScalars(data)
    local snap, count = {}, 0
    local function add(prefix, tbl, depth)
        for _, k in ipairs(sortedKeys(tbl)) do
            local v = tbl[k]
            local t = type(v)
            if t == "number" or t == "string" or t == "boolean" then
                if count < 60 then snap[prefix .. k] = v; count = count + 1 end
            elseif t == "table" and depth < 1 and v ~= tbl then
                add(prefix .. k .. ".", v, depth + 1)
            end
        end
    end
    add("", data, 0)
    return snap
end

function StreamDashboard:captureFieldData(data)
    if type(data) ~= "table" then return end
    local now = self.clock or 0
    self.fieldSeenClock = now
    if now - (self.fieldCaptureClock or -1e9) < FIELD_CAPTURE_EVERY_MS then return end
    self.fieldCaptureClock = now
    self.fieldCapture = snapshotScalars(data)
end

-- Se branche (en fin de fonction, sans rien modifier) sur les fonctions fieldAdd* du panneau d'info de champ.
-- Les fonctions du jeu ne sont enveloppees qu'UNE fois (la classe du jeu survit d'une partie a l'autre) ;
-- la cible de capture, elle, est reliee a chaque nouvelle partie.
function StreamDashboard:installFieldHooks()
    local cls = PlayerHUDUpdater
    if cls == nil or Utils == nil or type(Utils.appendedFunction) ~= "function" then return 0 end
    cls.streamDashboardCapture = function(_, data)
        pcall(StreamDashboard.captureFieldData, StreamDashboard, data)
    end
    cls.streamDashboardHooked = cls.streamDashboardHooked or {}
    local count = 0
    for _, name in ipairs(sortedKeys(cls)) do
        if string.sub(name, 1, 8) == "fieldAdd" and type(cls[name]) == "function" then
            count = count + 1
            if not cls.streamDashboardHooked[name] then
                cls.streamDashboardHooked[name] = true
                cls[name] = Utils.appendedFunction(cls[name], function(hud, data)
                    local capture = cls.streamDashboardCapture
                    if capture ~= nil then capture(hud, data) end
                end)
            end
        end
    end
    return count
end

local function readFieldState(x, z)
    if FieldState == nil or type(FieldState.new) ~= "function" then return nil end
    local ok, state = pcall(FieldState.new)
    if not ok or state == nil then return nil end
    if not pcall(state.update, state, x, z) then return nil end
    local snap = {}
    for _, k in ipairs({ "fruitTypeIndex", "growthState", "sprayLevel", "limeLevel", "plowLevel", "stubbleShredLevel",
                         "weedState", "rollerLevel", "stoneLevel", "groundType" }) do
        if type(state[k]) == "number" then snap[k] = state[k] end
    end
    return snap
end

local function pickNumber(snap, names, pattern)
    for _, name in ipairs(names) do
        if type(snap[name]) == "number" then return snap[name] end
    end
    if pattern ~= nil then
        for _, k in ipairs(sortedKeys(snap)) do
            local lower = string.lower(k)
            if type(snap[k]) == "number" and string.find(lower, pattern, 1, true) ~= nil
                and string.find(lower, "max", 1, true) == nil then
                return snap[k]
            end
        end
    end
    return nil
end

local function densityMax(name)
    local ok, value = pcall(function()
        local system = g_currentMission ~= nil and g_currentMission.fieldGroundSystem or nil
        if system == nil or FieldDensityMap == nil or FieldDensityMap[name] == nil then return nil end
        return system:getMaxValue(FieldDensityMap[name])
    end)
    if ok and type(value) == "number" and value > 0 then return value end
    return nil
end

local function farmNameById(farmId)
    if type(farmId) ~= "number" or farmId <= 0 or g_farmManager == nil then return nil end
    local ok, farm = pcall(g_farmManager.getFarmById, g_farmManager, farmId)
    if ok and farm ~= nil and type(farm.name) == "string" and farm.name ~= "" then return farm.name end
    return nil
end

local function levelPercent(value, max)
    if type(value) ~= "number" or type(max) ~= "number" or max <= 0 then return nil end
    return math.max(0, math.min(100, value / max * 100))
end

-- couleur de la culture sur la carte du jeu (couche Cultures) : valeurs brutes "r,g,b" (la page fait la conversion)
local fruitColorCache = {}
local function fruitMapColor(ft)
    if ft == nil or ft.index == nil then return nil end
    local c = fruitColorCache[ft.index]
    if c ~= nil then return c or nil end
    c = false
    pcall(function()
        local col = ft.defaultMapColor or ft.mapColor or (type(ft.mapColors) == "table" and (ft.mapColors.default or ft.mapColors[1])) or nil
        if type(col) == "table" and type(col[1]) == "number" and type(col[2]) == "number" and type(col[3]) == "number" then
            c = string.format("%.4f,%.4f,%.4f", col[1], col[2], col[3])
        end
    end)
    fruitColorCache[ft.index] = c
    return c or nil
end

local function decodeFieldState(info, snap)
    local fruitIndex = pickNumber(snap, { "fruitTypeIndex", "lastFruitTypeIndex" })
    local growth = pickNumber(snap, { "growthState", "lastGrowthState" })
    if type(fruitIndex) == "number" and fruitIndex > 0 and g_fruitTypeManager ~= nil then
        local ok, ft = pcall(g_fruitTypeManager.getFruitTypeByIndex, g_fruitTypeManager, fruitIndex)
        if ok and ft ~= nil then
            info.fruitIndex = fruitIndex
            local fill = ft.fillType
            if fill == nil and g_fillTypeManager ~= nil and ft.fillTypeIndex ~= nil then
                local ok2, f = pcall(g_fillTypeManager.getFillTypeByIndex, g_fillTypeManager, ft.fillTypeIndex)
                if ok2 then fill = f end
            end
            info.fruit = (fill ~= nil and fill.title) or ft.name
            info.fruitColor = fruitMapColor(ft)
            if type(growth) == "number" then
                info.growth = growth
                local minH, maxH = ft.minHarvestingGrowthState, ft.maxHarvestingGrowthState
                info.harvestReady = type(minH) == "number" and type(maxH) == "number" and growth >= minH and growth <= maxH
                local minP, maxP = ft.minPreparingGrowthState, ft.maxPreparingGrowthState
                if type(minP) == "number" and type(maxP) == "number" and minP > 0 and growth >= minP and growth <= maxP then
                    info.needsPrep = true                                  -- "retirer les fanes"
                end
                info.withered = (type(ft.witheredState) == "number" and growth == ft.witheredState) or nil
                info.cut = (type(ft.cutState) == "number" and growth == ft.cutState) or nil
                if info.harvestReady then
                    info.growthPct = 100
                elseif type(minH) == "number" and minH > 0 and not info.cut and not info.withered then
                    info.growthPct = math.max(0, math.min(100, growth / minH * 100))
                end
            end
        end
    end
    info.sprayLevel = pickNumber(snap, { "sprayLevel", "fertilizerLevel" }, "spray")
    info.limeLevel = pickNumber(snap, { "limeLevel" }, "lime")
    info.plowLevel = pickNumber(snap, { "plowLevel" }, "plow")
    info.weedState = pickNumber(snap, { "weedState" }, "weed")
    info.sprayPct = levelPercent(info.sprayLevel, densityMax("SPRAY_LEVEL"))
    info.limePct = levelPercent(info.limeLevel, densityMax("LIME_LEVEL"))
    info.plowPct = levelPercent(info.plowLevel, densityMax("PLOW_LEVEL"))
end

-- Renvoie la table d'info du champ (onField = false hors champ). 'snap' = capture recente du panneau du jeu, ou nil.
local function buildFieldInfo(x, z, snap)
    local info = { onField = false }
    if type(x) ~= "number" or type(z) ~= "number" then return info end

    local hasField = false
    if g_farmlandManager ~= nil then
        pcall(function()
            local id = g_farmlandManager:getFarmlandIdAtWorldPosition(x, z)
            if type(id) ~= "number" or id <= 0 then return end
            info.farmlandId = id
            info.number = id
            local ownerId = tryCall(g_farmlandManager, "getFarmlandOwner", id)          -- 0 = a vendre / sans proprietaire
            if type(ownerId) == "number" then
                info.ownerFarmId = ownerId
                info.owner = farmNameById(ownerId)
            end
            local farmland = g_farmlandManager:getFarmlandById(id)
            if farmland ~= nil then                                                      -- prix du terrain (affiche si a vendre)
                local price = farmland.price
                if type(price) ~= "number" then price = tryCall(farmland, "getPrice") end
                if type(price) == "number" and price > 0 then info.price = price end
            end
            local field = farmland ~= nil and farmland.field or nil
            if field ~= nil then
                hasField = true
                if type(field.fieldId) == "number" then info.number = field.fieldId end
                local area = tryCall(field, "getAreaHa")
                if type(area) ~= "number" then area = field.areaHa end
                if type(area) ~= "number" and farmland ~= nil then area = farmland.areaInHa end
                if type(area) ~= "number" then area = field.fieldArea end
                if type(area) == "number" then
                    if area > 300 then area = area / 10000 end           -- metres carres -> hectares
                    info.areaHa = area
                end
            end
        end)
    end

    local state, source = snap, "hud"
    if state == nil and hasField then
        state, source = readFieldState(x, z), "state"
    end
    if state ~= nil then
        pcall(decodeFieldState, info, state)
        if info.ownerFarmId == nil then                                              -- repli : donnees du panneau du jeu
            local ownerId = pickNumber(state, { "ownerFarmId", "farmId" })
            if type(ownerId) == "number" then
                info.ownerFarmId = ownerId
                info.owner = farmNameById(ownerId)
            end
        end
        info.source = source
        info.onField = (source == "hud") or hasField
    else
        info.onField = hasField
    end
    return info
end

-- ------------------------------------------------------- JOUEURS / CARTE ----
-- Position (x, z) et direction (dx, dz) d'un noeud du monde.
local function nodePosDir(node)
    if node == nil or getWorldTranslation == nil then return nil end
    local ok, x, _, z = pcall(getWorldTranslation, node)
    if not ok or type(x) ~= "number" or type(z) ~= "number" then return nil end
    local dx, dz = nil, nil
    if localDirectionToWorld ~= nil then
        local ok2, ddx, _, ddz = pcall(localDirectionToWorld, node, 0, 0, 1)
        if ok2 and type(ddx) == "number" and type(ddz) == "number" then dx, dz = ddx, ddz end
    end
    return x, z, dx, dz
end

local function safeField(obj, name)
    if type(obj) ~= "table" then return nil end
    local ok, v = pcall(function() return obj[name] end)
    if ok then return v end
    return nil
end

local function playerName(player, mission)
    for _, f in ipairs({ "nickname", "playerName" }) do
        local v = safeField(player, f)
        if type(v) == "string" and v ~= "" then return v end
    end
    local v = tryCall(player, "getNickname")
    if type(v) == "string" and v ~= "" then return v end
    local userId = safeField(player, "userId")
    local um = mission ~= nil and mission.userManager or nil
    if userId ~= nil and um ~= nil then
        local user = tryCall(um, "getUserByUserId", userId)
        local nick = tryCall(user, "getNickname") or safeField(user, "nickname")
        if type(nick) == "string" and nick ~= "" then return nick end
    end
    return nil
end

-- Liste des joueurs connus par le jeu (en multi : tous ; en solo : soi-meme). Renvoie la liste et la source.
local function collectPlayers(mission)
    local list, seen, src = {}, {}, {}
    local function add(p, label)
        if type(p) ~= "table" or seen[p] or safeField(p, "rootNode") == nil then return end
        seen[p] = true
        table.insert(list, p)
        src[label] = true
    end
    local ps = mission ~= nil and mission.playerSystem or nil
    if ps ~= nil then
        local all = tryCall(ps, "getPlayers")
        if type(all) == "table" then for _, p in pairs(all) do add(p, "getPlayers") end end
        for _, f in ipairs({ "players", "playersByUserId", "playerByUserId", "playersByConnection" }) do
            local t = safeField(ps, f)
            if type(t) == "table" then for _, p in pairs(t) do add(p, f) end end
        end
    end
    if g_localPlayer ~= nil then add(g_localPlayer, "g_localPlayer") end
    if mission ~= nil and mission.player ~= nil then add(mission.player, "mission.player") end
    local names = {}
    for k in pairs(src) do table.insert(names, k) end
    table.sort(names)
    return list, table.concat(names, "+")
end

-- A pied, le noeud racine du joueur ne tourne pas : on lit la camera (soi) ou le modele du personnage (autres).
local function nodeDir(node, sign)
    if node == nil or localDirectionToWorld == nil then return nil end
    local ok, dx, _, dz = pcall(localDirectionToWorld, node, 0, 0, sign or 1)
    if ok and type(dx) == "number" and type(dz) == "number" and (math.abs(dx) + math.abs(dz)) > 0.01 then return dx, dz end
    return nil
end

local function onFootDirection(p, isSelf)
    if isSelf and getCamera ~= nil then
        local ok, cam = pcall(getCamera)
        if ok and cam ~= nil and cam ~= 0 then
            local dx, dz = nodeDir(cam, -1)                     -- une camera regarde vers -Z
            if dx ~= nil then return dx, dz, "camera" end
        end
    end
    local gc = safeField(p, "graphicsComponent")
    local model = safeField(p, "model")
    local candidates = {
        { tryCall(p, "getGraphicsRootNode"), "getGraphicsRootNode" },
        { safeField(p, "graphicsRootNode"), "graphicsRootNode" },
        { gc ~= nil and safeField(gc, "graphicsRootNode") or nil, "graphicsComponent.graphicsRootNode" },
        { model ~= nil and safeField(model, "rootNode") or nil, "model.rootNode" },
        { safeField(p, "modelNode"), "modelNode" },
    }
    for _, c in ipairs(candidates) do
        if type(c[1]) == "number" and c[1] ~= 0 then
            local dx, dz = nodeDir(c[1], 1)
            if dx ~= nil then return dx, dz, c[2] end
        end
    end
    return nil
end

-- Mode compagnon : ce que fait chaque joueur (vehicule + outils attaches, categorie boutique, remplissage).
local function storeCategory(v)
    local si = getStoreItem(v)
    if si == nil then return nil end
    local c = si.categoryName
    if type(c) ~= "string" and type(si.categoryNames) == "table" then c = si.categoryNames[1] end
    if type(c) == "string" then return c end
    return nil
end

local function fillSummary(v)
    local spec = v ~= nil and v.spec_fillUnit or nil
    if spec == nil or spec.fillUnits == nil then return nil end
    local bestCap, bestLvl, bestType = 0, 0, nil
    for index, unit in ipairs(spec.fillUnits) do
        pcall(function()
            if unit.showOnHud == false or isConsumerUnit(unit) then return end
            local cap = v:getFillUnitCapacity(index)
            if type(cap) ~= "number" or cap <= 0 or cap > 1e9 then return end
            if cap > bestCap then
                bestCap = cap
                bestLvl = v:getFillUnitFillLevel(index) or 0
                local ft = getFillTypeInfo(v:getFillUnitFillType(index))
                bestType = (bestLvl > 0.01 and ft ~= nil) and ft.title or nil
            end
        end)
    end
    if bestCap <= 0 then return nil end
    return math.floor(math.max(0, math.min(1, bestLvl / bestCap)) * 100 + 0.5), bestType
end

local function toolsOf(vehicle, withImg)
    local list, seen = {}, {}
    local function add(v, depth)
        if type(v) ~= "table" or seen[v] or depth > StreamDashboard.MAX_IMPLEMENT_DEPTH or #list >= 6 then return end
        seen[v] = true
        local t = { n = getVehicleName(v), c = storeCategory(v) }
        local pct, ft = fillSummary(v)
        if pct ~= nil then t.f = pct; t.ft = ft end
        if tryCall(v, "getIsTurnedOn") == true then t.on = true end
        if tryCall(v, "getIsLowered") == true then t.lo = true end
        if withImg then                                                   -- 1.4.4 : photo dans la fiche du compagnon
            t.img = getImagePath(v, getStoreItem(v))
            t.xml = normalizePath(v.configFileName)
            t.mod = v.customEnvironment
        end
        table.insert(list, t)
        local ok, att = pcall(function() return v.getAttachedImplements ~= nil and v:getAttachedImplements() or nil end)
        if ok and type(att) == "table" then
            for _, e in pairs(att) do
                if type(e) == "table" then add(e.object or e.vehicle or e, depth + 1) end
            end
        end
    end
    pcall(add, vehicle, 1)
    return list
end

-- 1.4.4 : AFK automatique (5 min sans bouger ni tourner)
local AFK_MS = 5 * 60 * 1000
local afkState = {}
local function afkMinutes(name, x, z, dx, dz, clock)
    local a = afkState[name]
    local moved = a == nil or math.abs(x - a.x) > 0.5 or math.abs(z - a.z) > 0.5
    if not moved and dx ~= nil and a.dx ~= nil and (math.abs(dx - a.dx) > 0.05 or math.abs(dz - a.dz) > 0.05) then moved = true end
    if moved then
        afkState[name] = { x = x, z = z, dx = dx, dz = dz, t = clock }
        return nil
    end
    local ms = clock - a.t
    if ms >= AFK_MS then return math.floor(ms / 60000) end
    return nil
end

local function describePlayers(mission, clock)
    local out, lua = {}, {}
    local afkSeen = {}
    local players, source = collectPlayers(mission)
    for _, p in ipairs(players) do
        if #out >= 16 then break end
        local vehicle = tryCall(p, "getCurrentVehicle") or safeField(p, "currentVehicle")
        if type(vehicle) ~= "table" then vehicle = nil end
        local node = (vehicle ~= nil and vehicle.rootNode) or safeField(p, "rootNode")
        local x, z, dx, dz = nodePosDir(node)
        if x ~= nil and not (x == 0 and z == 0) then
            local isSelf = (p == g_localPlayer) or (mission ~= nil and p == mission.player) or safeField(p, "isOwner") == true
            local item = { name = playerName(p, mission) or (isSelf and "Moi" or "Joueur"), x = x, z = z, self = isSelf }
            if vehicle == nil then
                local fdx, fdz, fsrc = onFootDirection(p, isSelf)
                if fdx ~= nil then dx, dz = fdx, fdz; item.dirSrc = fsrc end
            end
            if dx ~= nil then item.dx = dx; item.dz = dz end
            if vehicle ~= nil then
                item.vehicle = getVehicleName(vehicle)
                local tools = toolsOf(vehicle)
                if #tools > 0 then
                    local enc = {}
                    for _, t in ipairs(tools) do table.insert(enc, jsonObject(t)) end
                    item.tools = raw("[" .. table.concat(enc, ",") .. "]")
                    item.toolsLua = tools
                end
                local lvl, cap = getFuel(vehicle)
                if lvl ~= nil then item.fuel = math.floor(lvl / cap * 100 + 0.5) end
            end
            local farmId = safeField(p, "farmId") or tryCall(p, "getFarmId")
            if type(farmId) == "number" then item.farmId = farmId end
            afkSeen[item.name] = true
            item.afk = afkMinutes(item.name, x, z, item.dx, item.dz, clock or 0)
            table.insert(lua, { name = item.name, self = isSelf, x = x, z = z, vehicle = item.vehicle, tools = item.toolsLua, farmId = item.farmId, afk = item.afk })
            item.toolsLua = nil
            table.insert(out, jsonObject(item))
        end
    end
    for k in pairs(afkState) do if not afkSeen[k] then afkState[k] = nil end end
    return out, source, lua
end

-- Taille du terrain et fichiers de la map (pour l'image de fond de la mini-carte). Calcule une fois par partie.
local function getMapInfo(mission)
    local m = {}
    if mission == nil then return m end
    pcall(function()
        local size = mission.terrainSize
        if type(size) ~= "number" and mission.terrainRootNode ~= nil and getTerrainSize ~= nil then
            size = getTerrainSize(mission.terrainRootNode)
        end
        if type(size) == "number" then m.size = size end
        if type(mission.mapWidth) == "number" then m.width = mission.mapWidth end
        if type(mission.mapHeight) == "number" then m.height = mission.mapHeight end
    end)
    pcall(function()
        local info = mission.missionInfo
        local img = safeField(mission, "mapImageFilename")
        local hud = safeField(mission, "hud")
        local ingame = hud ~= nil and safeField(hud, "ingameMap") or nil
        if (img == nil or img == "") and ingame ~= nil then
            img = safeField(ingame, "mapImageFilename") or safeField(ingame, "filename")
        end
        if type(img) == "string" and img ~= "" then m.image = normalizePath(img) end
        if ingame ~= nil then                                  -- partie jouable dans l'image de la carte
            local sc = safeField(ingame, "mapExtensionScaleFactor")
            local ox = safeField(ingame, "mapExtensionOffsetX")
            local oz = safeField(ingame, "mapExtensionOffsetZ")
            if type(sc) == "number" then m.extScale = sc end
            if type(ox) == "number" then m.extOffX = ox end
            if type(oz) == "number" then m.extOffZ = oz end
        end
        if info ~= nil then
            local xml = info.mapXMLFilename
            local base = info.baseDirectory
            local map = info.map
            if map ~= nil then
                base = base or map.baseDirectory
                xml = xml or map.mapXMLFilename
                if type(map.title) == "string" then m.title = map.title end
            end
            if type(base) == "string" and base ~= "" then m.baseDir = normalizePath(base) end
            if type(xml) == "string" and xml ~= "" then
                if Utils ~= nil and Utils.getFilename ~= nil and type(base) == "string" then
                    local ok, full = pcall(Utils.getFilename, xml, base)
                    if ok and type(full) == "string" then xml = full end
                end
                m.mapXml = normalizePath(xml)
            end
            if m.title == nil and type(info.mapTitle) == "string" then m.title = info.mapTitle end
        end
    end)
    return m
end

-- ------------------------------------------------- COUCHES DE CHAMPS (MINI-CARTE) ----
-- Contour de chaque champ (envoye une fois dans fields.json) et etat de chaque champ (tourne en continu,
-- quelques champs par seconde). Les fonctions FS25 utilisees ne sont pas documentees : plusieurs essais, tout garde.
local function roundTo(v) return math.floor(v * 10 + 0.5) / 10 end

local function flatPoints(t)
    if type(t) ~= "table" then return nil end
    local out = {}
    if type(t[1]) == "number" then
        if #t < 6 or #t % 2 ~= 0 then return nil end
        for i = 1, #t do out[i] = roundTo(t[i]) end
    elseif type(t[1]) == "table" then
        for _, p in ipairs(t) do
            local x = p.x or p[1]
            local z = p.z or (p[3] ~= nil and p[3]) or p[2]
            if type(x) ~= "number" or type(z) ~= "number" then return nil end
            table.insert(out, roundTo(x)); table.insert(out, roundTo(z))
        end
        if #out < 6 then return nil end
    else
        return nil
    end
    -- allege les contours tres detailles (max 160 points)
    if #out > 320 then
        local step, light = math.ceil(#out / 320), {}
        for i = 1, #out - 1, 2 * step do table.insert(light, out[i]); table.insert(light, out[i + 1]) end
        out = light
    end
    return out
end

-- Certaines fonctions renvoient des NOEUDS de la scene (identifiants) et non des coordonnees : on les convertit.
local function nodesToPoints(t)
    if type(t) ~= "table" or type(t[1]) ~= "number" or entityExists == nil or getWorldTranslation == nil then return nil end
    for i = 1, math.min(3, #t) do
        local v = t[i]
        if type(v) ~= "number" or v ~= math.floor(v) then return nil end
        local ok, exists = pcall(entityExists, v)
        if not ok or not exists then return nil end
    end
    local out = {}
    for _, node in ipairs(t) do
        local ok, x, _, z = pcall(getWorldTranslation, node)
        if ok and type(x) == "number" and type(z) == "number" then
            table.insert(out, roundTo(x)); table.insert(out, roundTo(z))
        end
    end
    return flatPoints(out)
end

-- garde-fou : un contour avec des coordonnees hors de toute map est rejete
local function sanePoints(pts)
    if pts == nil then return nil end
    for i = 1, #pts do
        if type(pts[i]) ~= "number" or math.abs(pts[i]) > 10000 then return nil end
    end
    return pts
end

local function fieldPolygons(field)
    for _, m in ipairs({ "getPolygonPoints", "getVerticesList", "getVertices", "getPolygon" }) do
        local res = tryCall(field, m)
        local pts = sanePoints(nodesToPoints(res)) or sanePoints(flatPoints(res))
        if pts then return { pts }, m .. "()" end
    end
    for _, f in ipairs({ "polygonPoints", "polygon", "densityMapPolygon", "vertices", "points" }) do
        local v = safeField(field, f)
        if type(v) == "table" then
            local pts = sanePoints(nodesToPoints(v)) or sanePoints(flatPoints(v))
                or sanePoints(flatPoints(tryCall(v, "getVerticesList"))) or sanePoints(flatPoints(tryCall(v, "getVertices")))
                or sanePoints(flatPoints(safeField(v, "points"))) or sanePoints(flatPoints(safeField(v, "vertices")))
            if pts then return { pts }, f end
        end
    end
    -- ancien format (FS22) : parallelogrammes sous le noeud fieldDimensions
    local dim = safeField(field, "fieldDimensions")
    if dim ~= nil and getNumOfChildren ~= nil and getChildAt ~= nil and getWorldTranslation ~= nil then
        local polys = {}
        pcall(function()
            for i = 0, getNumOfChildren(dim) - 1 do
                local c = getChildAt(dim, i)
                local x0, _, z0 = getWorldTranslation(c)
                local x1, _, z1 = getWorldTranslation(getChildAt(c, 0))
                local x2, _, z2 = getWorldTranslation(getChildAt(c, 1))
                table.insert(polys, { roundTo(x0), roundTo(z0), roundTo(x1), roundTo(z1),
                    roundTo(x1 + x2 - x0), roundTo(z1 + z2 - z0), roundTo(x2), roundTo(z2) })
            end
        end)
        if #polys > 0 then return polys, "fieldDimensions" end
    end
    return nil, nil
end

local function fieldCenter(field, polys)
    local ok, x, z = pcall(function()
        if type(field.getCenterOfFieldWorldPosition) == "function" then return field:getCenterOfFieldWorldPosition() end
        return nil
    end)
    if ok and type(x) == "number" and type(z) == "number" then return x, z end
    local px, pz = safeField(field, "posX"), safeField(field, "posZ")
    if type(px) == "number" and type(pz) == "number" then return px, pz end
    if polys and polys[1] then
        local sx, sz, n = 0, 0, 0
        for i = 1, #polys[1] - 1, 2 do sx = sx + polys[1][i]; sz = sz + polys[1][i + 1]; n = n + 1 end
        if n > 0 then return sx / n, sz / n end
    end
    return nil
end

local function allFields()
    if g_fieldManager == nil then return {} end
    local list = tryCall(g_fieldManager, "getFields") or safeField(g_fieldManager, "fields") or {}
    local out = {}
    for _, f in pairs(list) do if type(f) == "table" then table.insert(out, f) end end
    return out
end

local function fieldId(field)
    local id = safeField(field, "fieldId") or tryCall(field, "getId") or safeField(field, "id")
    if type(id) == "number" then return id end
    return nil
end

local GROUND_NAMES = nil
local function groundTypeName(v)
    if type(v) ~= "number" or FieldGroundType == nil then return nil end
    if GROUND_NAMES == nil then
        GROUND_NAMES = {}
        for k, val in pairs(FieldGroundType) do
            if type(k) == "string" and type(val) == "number" then GROUND_NAMES[val] = k end
        end
    end
    return GROUND_NAMES[v]
end

-- Etat d'un champ : d'abord celui que le jeu tient a jour (field.fieldState), sinon calcul au centre du champ.
local function isClientOnly()
    local m = g_currentMission
    if m == nil then return false end
    local server = tryCall(m, "getIsServer")
    if server == nil then server = (g_server ~= nil) end
    return server == false
end

-- Mode compagnon : proprietaire, surface et prix (si a vendre) de chaque champ.
local function farmlandOf(field, cx, cz)
    local out = {}
    if g_farmlandManager == nil then return out end
    pcall(function()
        local farmland = safeField(field, "farmland")
        local id = farmland ~= nil and safeField(farmland, "id") or nil
        if type(id) ~= "number" and cx ~= nil then id = g_farmlandManager:getFarmlandIdAtWorldPosition(cx, cz) end
        if type(id) ~= "number" or id <= 0 then return end
        if farmland == nil then farmland = g_farmlandManager:getFarmlandById(id) end
        local owner = tryCall(g_farmlandManager, "getFarmlandOwner", id)
        if type(owner) == "number" then
            out.of = owner
            out.on = farmNameById(owner)
        end
        if owner == 0 and farmland ~= nil then
            local price = safeField(farmland, "price")
            if type(price) ~= "number" then price = tryCall(farmland, "getPrice") end
            if type(price) == "number" and price > 0 then out.pr = math.floor(price + 0.5) end
        end
        local area = tryCall(field, "getAreaHa")
        if type(area) ~= "number" then area = safeField(field, "areaHa") end
        if type(area) ~= "number" and farmland ~= nil then area = safeField(farmland, "areaInHa") end
        if type(area) == "number" and area > 0 then
            if area > 300 then area = area / 10000 end
            out.ha = math.floor(area * 100 + 0.5) / 100
        end
    end)
    return out
end

local function fieldStateOf(field, cx, cz)
    local snap, src = nil, nil
    if isClientOnly() and cx ~= nil then                        -- multi (joueur connecte) : lecture du sol au centre du champ
        snap = readFieldState(cx, cz)
        if snap ~= nil and next(snap) ~= nil then src = "FieldState (multi)" else snap = nil end
    end
    local fs = snap == nil and safeField(field, "fieldState") or nil
    if type(fs) == "table" then
        snap = {}
        for _, k in ipairs({ "fruitTypeIndex", "growthState", "sprayLevel", "limeLevel", "plowLevel", "weedState", "groundType" }) do
            local v = safeField(fs, k)
            if type(v) == "number" then snap[k] = v end
        end
        if next(snap) == nil then snap = nil else src = "fieldState" end
    end
    if snap == nil and cx ~= nil then snap, src = readFieldState(cx, cz), "FieldState" end
    local land = farmlandOf(field, cx, cz)
    if snap == nil then
        if next(land) == nil then return nil end
        return land, "farmland"
    end
    local info = {}
    pcall(decodeFieldState, info, snap)
    local out = { gt = groundTypeName(snap.groundType) }
    for k, v in pairs(land) do out[k] = v end
    if type(info.weedState) == "number" then out.ws = info.weedState end
    if info.fruitIndex then out.fi = info.fruitIndex; out.fn = info.fruit; out.fc = info.fruitColor end
    if info.growthPct then out.gp = math.floor(info.growthPct + 0.5) end
    if info.harvestReady then out.ready = true end
    if info.cut then out.cut = true end
    if info.withered then out.wither = true end
    if info.needsPrep then out.prep = true end
    if info.sprayPct then out.sp = math.floor(info.sprayPct + 0.5) end
    if info.limePct then out.lp = math.floor(info.limePct + 0.5) end
    if info.plowPct then out.pp = math.floor(info.plowPct + 0.5) end
    return out, src
end


-- ------------------------------------------------------- DANS LE JEU (HUD) ----
-- Mode compagnon dans le jeu : A notifications, B panneau "A faire", C encart en entrant dans un champ,
-- D "qui fait quoi" (touche SD_TOGGLE, F9 par defaut, modifiable dans les commandes du jeu). Reglages et notes ecrits par l'application dans modSettings :
-- ingame.xml (interrupteurs, taille, positions) et notes.xml (notes des champs, par carte).
-- XML et pas JSON : dans FS25, io.open ne permet pas de LIRE un fichier (pas de file:read), loadXMLFile oui.
-- Les fonctions de dessin du jeu ne sont pas documentees : tout est protege par pcall.

local HUD_TXT = {
    fr = { todo = "À FAIRE · MES CHAMPS", who = "QUI FAIT QUOI", key = "F9", nothing = "Rien à faire",
           harvest = "Récolter", prep = "Retirer les fanes", weed = "Désherber", fert = "Fertiliser", lime = "Chauler",
           plow = "Labourer", sow = "Semer", field = "Champ", ready = "prêt à récolter", withered = "a fané",
           full = "Remorque pleine", fullH = "Trémie pleine", onFoot = "à pied", fertPct = "engrais", lime2 = "chaux",
           ok = "OK", toLime = "à chauler", toPlow = "à labourer", growth = "croissance", empty = "vide", cut = "récolté",
           more = "et %d autre(s)", forSale = "à vendre", me = "moi", weeds = "mauvaises herbes",
           weather = "PRÉVISIONS MÉTÉO", fieldnow = "CHAMP ACTUEL", alerts = "DERNIÈRES ALERTES",
           fuel = "Carburant", cond = "État", noAlert = "Aucune alerte", ago = "il y a %d min", now = "à l'instant",
           tomorrow = "Demain", inDays = "J+%d", lime3 = "Chaux", plow2 = "Labour", fert2 = "Engrais", note = "Note",
           SUN = "Ensoleillé", CLEAR = "Dégagé", CLOUDY = "Nuageux", RAIN = "Pluie", SNOW = "Neige", FOG = "Brouillard",
           THUNDER = "Orage", HAIL = "Grêle", TWISTER = "Tornade", rainSoon = "pluie à venir",
           rainAt = "pluie", num = "N°", growth2 = "Croissance", missing = "il manque", prodStopped = "à l'arrêt",
           outFull = "stock de sortie plein", lowFood = "nourriture presque vide", bestMonth = "Meilleur mois pour vendre :" },
    en = { todo = "TO DO · MY FIELDS", who = "WHO DOES WHAT", key = "F9", nothing = "Nothing to do",
           harvest = "Harvest", prep = "Remove haulm", weed = "Weed", fert = "Fertilize", lime = "Lime",
           plow = "Plow", sow = "Sow", field = "Field", ready = "ready to harvest", withered = "withered",
           full = "Trailer full", fullH = "Tank full", onFoot = "on foot", fertPct = "fertilizer", lime2 = "lime",
           ok = "OK", toLime = "needs lime", toPlow = "needs plowing", growth = "growth", empty = "empty", cut = "harvested",
           more = "and %d more", forSale = "for sale", me = "me", weeds = "weeds",
           weather = "WEATHER FORECAST", fieldnow = "CURRENT FIELD", alerts = "LATEST ALERTS",
           fuel = "Fuel", cond = "Condition", noAlert = "No alerts", ago = "%d min ago", now = "just now",
           tomorrow = "Tomorrow", inDays = "D+%d", lime3 = "Lime", plow2 = "Plow", fert2 = "Fertilizer", note = "Note",
           SUN = "Sunny", CLEAR = "Clear", CLOUDY = "Cloudy", RAIN = "Rain", SNOW = "Snow", FOG = "Fog",
           THUNDER = "Thunderstorm", HAIL = "Hail", TWISTER = "Twister", rainSoon = "rain coming",
           rainAt = "rain", num = "No.", growth2 = "Growth", missing = "missing", prodStopped = "stopped",
           outFull = "output storage full", lowFood = "food almost empty", bestMonth = "Best month to sell:" },
}
-- Langue du jeu : plusieurs sources possibles (elles changent selon les versions de FS25), la 1re qui repond gagne.
-- Le texte "sd_lang" est declare dans modDesc.xml (<l10n>) : le jeu le donne dans sa langue (fr / en / de...).
local HUD_LANG, HUD_LANG_SRC = nil, nil
local function hudLang()
    if HUD_LANG ~= nil then return HUD_LANG end
    local found, src = nil, nil
    local function try(v, name)
        if found == nil and type(v) == "string" and v ~= "" and v ~= "sd_lang" then
            found, src = string.lower(v), name
        end
    end
    if g_i18n ~= nil and type(g_i18n.getText) == "function" then
        local ok, v = pcall(g_i18n.getText, g_i18n, "sd_lang")
        if ok and type(v) == "string" and #v <= 5 and not string.find(v, "Missing", 1, true) then try(v, "l10n") end
    end
    try(g_languageShortName, "g_languageShortName")
    local suffix = g_languageSuffix
    if type(suffix) == "string" then try((suffix:gsub("^_", "")), "g_languageSuffix") end
    if g_i18n ~= nil then
        local ok, v = pcall(function() return g_i18n.languageShortName end)
        if ok then try(v, "g_i18n.languageShortName") end
    end
    local getLang, getCode = getLanguage, getLanguageCode
    if type(getLang) == "function" and type(getCode) == "function" then
        local ok, id = pcall(getLang)
        if ok then local ok2, code = pcall(getCode, id); if ok2 then try(code, "getLanguageCode") end end
    end
    if found == nil then
        HUD_LANG, HUD_LANG_SRC = "fr", "par defaut"                  -- langue de l'auteur si rien ne repond
    else
        HUD_LANG, HUD_LANG_SRC = (string.sub(found, 1, 2) == "fr") and "fr" or "en", src .. "=" .. found
    end
    print("[StreamDashboard] langue de l'affichage dans le jeu : " .. HUD_LANG .. " (" .. tostring(HUD_LANG_SRC) .. ")")
    return HUD_LANG
end
local function T(key)
    local lang = hudLang()
    return HUD_TXT[lang][key] or HUD_TXT.en[key] or key
end

-- petit lecteur JSON (objets, tableaux, textes, nombres, vrai/faux/null)
local function utf8char(c)
    if c < 0x80 then return string.char(c) end
    if c < 0x800 then return string.char(0xC0 + math.floor(c / 64), 0x80 + c % 64) end
    return string.char(0xE0 + math.floor(c / 4096), 0x80 + math.floor(c / 64) % 64, 0x80 + c % 64)
end
local function jsonDecode(str)
    if type(str) ~= "string" then return nil end
    local pos = 1
    local function ws() pos = str:find("[^ \t\r\n]", pos) or (#str + 1) end
    local value
    local function strv()
        local out, i = {}, pos + 1
        while true do
            local c = str:sub(i, i)
            if c == "" then error("fin de texte") end
            if c == '"' then pos = i + 1; return table.concat(out) end
            if c == "\\" then
                local n = str:sub(i + 1, i + 1)
                if n == "u" then
                    out[#out + 1] = utf8char(tonumber(str:sub(i + 2, i + 5), 16) or 63); i = i + 6
                else
                    local map = { n = "\n", t = "\t", r = "\r", b = "\b", f = "\f" }
                    out[#out + 1] = map[n] or n; i = i + 2
                end
            else
                local j = str:find('["\\]', i) or (#str + 1)
                out[#out + 1] = str:sub(i, j - 1); i = j
            end
        end
    end
    value = function()
        ws()
        local c = str:sub(pos, pos)
        if c == "{" then
            local t = {}; pos = pos + 1; ws()
            if str:sub(pos, pos) == "}" then pos = pos + 1; return t end
            while true do
                ws(); local k = strv(); ws()
                if str:sub(pos, pos) ~= ":" then error("':' attendu") end
                pos = pos + 1; t[k] = value(); ws()
                local d = str:sub(pos, pos); pos = pos + 1
                if d == "}" then return t end
                if d ~= "," then error("',' attendu") end
            end
        elseif c == "[" then
            local t = {}; pos = pos + 1; ws()
            if str:sub(pos, pos) == "]" then pos = pos + 1; return t end
            while true do
                t[#t + 1] = value(); ws()
                local d = str:sub(pos, pos); pos = pos + 1
                if d == "]" then return t end
                if d ~= "," then error("',' attendu") end
            end
        elseif c == '"' then return strv()
        elseif str:sub(pos, pos + 3) == "true" then pos = pos + 4; return true
        elseif str:sub(pos, pos + 4) == "false" then pos = pos + 5; return false
        elseif str:sub(pos, pos + 3) == "null" then pos = pos + 4; return nil
        else
            local num = str:match("^-?%d+%.?%d*[eE]?[-+]?%d*", pos)
            if num == nil or num == "" then error("valeur inconnue") end
            pos = pos + #num; return tonumber(num)
        end
    end
    local ok, res = pcall(value)
    if ok then return res end
    return nil
end


-- type de travail d'apres la categorie de la boutique (meme liste que la page compagnon)
local WORKS = {
    { "FORAGEHARVEST", "Ensilage", "Chopping" }, { "BEETHARVEST", "Betteraves", "Beets" }, { "POTATOHARVEST", "Pommes de terre", "Potatoes" },
    { "HARVESTER", "Moisson", "Harvesting" }, { "CUTTER", "Moisson", "Harvesting" }, { "SEEDER", "Semis", "Sowing" }, { "PLANTER", "Semis", "Sowing" },
    { "PLOW", "Labour", "Plowing" }, { "SUBSOIL", "Travail du sol", "Tillage" }, { "SPADER", "Travail du sol", "Tillage" },
    { "DISCHARROW", "Travail du sol", "Tillage" }, { "POWERHARROW", "Travail du sol", "Tillage" }, { "CULTIVAT", "Travail du sol", "Tillage" },
    { "WEEDER", "Désherbage", "Weeding" }, { "SPRAYER", "Pulvérisation", "Spraying" }, { "LIME", "Chaulage", "Liming" },
    { "FERTILIZERSPREAD", "Engrais", "Fertilizing" }, { "MANURE", "Fumier", "Manure" }, { "SLURRY", "Lisier", "Slurry" },
    { "MOWER", "Fauche", "Mowing" }, { "TEDDER", "Fanage", "Tedding" }, { "WINDROW", "Andainage", "Windrowing" },
    { "BALER", "Pressage", "Baling" }, { "MULCH", "Broyage", "Mulching" }, { "ROLLER", "Roulage", "Rolling" },
    { "STONE", "Pierres", "Stones" }, { "LOADERWAGON", "Autochargeuse", "Loader wagon" }, { "FORAGEWAGON", "Autochargeuse", "Loader wagon" },
    { "AUGER", "Transbordement", "Overloading" }, { "TRAILER", "Transport", "Transport" }, { "TIPPER", "Transport", "Transport" },
}
local function workName(cat)
    if type(cat) ~= "string" then return nil end
    local c = cat:upper()
    for _, w in ipairs(WORKS) do
        if c:find(w[1], 1, true) then return (hudLang() == "fr") and w[2] or w[3] end
    end
    return nil
end
local function workOfTools(tools)
    if type(tools) ~= "table" then return nil end
    for i = 2, #tools do local w = workName(tools[i].c); if w then return w end end
    if tools[1] then return workName(tools[1].c) end
    return nil
end
local NO_FULL_ALERT = { "SEED", "PLANT", "SPRAY", "FERTI", "SPREAD", "LIME", "MANURE", "SLURRY", "WEED" }

local function fieldIdAt(x, z)
    if g_farmlandManager == nil or type(x) ~= "number" then return nil end
    local ok, id = pcall(function()
        local fid = g_farmlandManager:getFarmlandIdAtWorldPosition(x, z)
        if type(fid) ~= "number" or fid <= 0 then return nil end
        local farmland = g_farmlandManager:getFarmlandById(fid)
        local field = farmland ~= nil and farmland.field or nil
        if field ~= nil and type(field.fieldId) == "number" then return field.fieldId end
        return nil
    end)
    if ok then return id end
    return nil
end

local function myFarmId()
    local m = g_currentMission
    local id = m ~= nil and tryCall(m, "getFarmId") or nil
    if type(id) == "number" then return id end
    return nil
end

-- A : notification du jeu (sinon un bandeau dessine par le mod)
function StreamDashboard:hudNotify(text, kind)
    local s = self.ingame or {}
    self.hudSent = self.hudSent or {}
    local now = self.clock or 0
    if self.hudSent[text] ~= nil and now - self.hudSent[text] < 600000 then return end   -- pas deux fois en 10 min
    self.hudSent[text] = now
    self.hudAlertLog = self.hudAlertLog or {}
    self.alertSeq = (self.alertSeq or 0) + 1
    table.insert(self.hudAlertLog, 1, { text = text, at = now, kind = kind, id = self.alertSeq })
    while #self.hudAlertLog > 5 do table.remove(self.hudAlertLog) end
    if s.notif == false then return end
    local m, ok = g_currentMission, false
    local col = (FSBaseMission ~= nil and FSBaseMission.INGAME_NOTIFICATION_INFO) or { 1, 1, 1, 1 }
    if m ~= nil and m.hud ~= nil and m.hud.addSideNotification ~= nil then
        local dur = (type(s.notifSec) == "number" and math.max(2, math.min(s.notifSec, 60)) or 7) * 1000
        ok = pcall(m.hud.addSideNotification, m.hud, col, text, dur)
    end
    if not ok and m ~= nil and m.addIngameNotification ~= nil then
        ok = pcall(m.addIngameNotification, m, col, text)
    end
    if not ok then self.hudToast = { text = text, untilClock = now + 7000 } end
    print("[StreamDashboard] notification : " .. text .. (ok and "" or " (bandeau du mod)"))
end

-- lecture d'un XML ecrit par l'application (fonctions XML du jeu, toutes protegees)
local function withXml(path, fn)
    if loadXMLFile == nil or path == nil then return nil end
    if fileExists ~= nil then
        local okE, exists = pcall(fileExists, path)
        if okE and exists == false then return nil end
    end
    local ok, id = pcall(loadXMLFile, "streamDashboardXml", path)
    if not ok or id == nil or id == 0 then return nil end
    local okF, res = pcall(fn, id)
    if delete ~= nil then pcall(delete, id) end
    if okF then return res end
    return nil
end

local function readIngameXml(path)
    return withXml(path, function(x)
        local out = { pos = {} }
        for _, k in ipairs({ "notif", "todo", "field", "who", "weather", "fieldnow", "alerts" }) do
            local v = getXMLBool(x, "ingame#" .. k)
            if v ~= nil then out[k] = v end
        end
        local sc = getXMLFloat(x, "ingame#scale")
        if type(sc) == "number" then out.scale = sc end
        local fs = getXMLFloat(x, "ingame#fieldSec")
        if type(fs) == "number" then out.fieldSec = fs end
        local as, ns = getXMLFloat(x, "ingame#alertSec"), getXMLFloat(x, "ingame#notifSec")
        if type(as) == "number" then out.alertSec = as end
        if type(ns) == "number" then out.notifSec = ns end
        local af = getXMLString(x, "ingame#alertFarm")                     -- 1.4.4 : "mine" (defaut) ou "all"
        if af == "mine" or af == "all" then out.alertFarm = af end
        for _, k in ipairs({ "todo", "who", "field", "weather", "fieldnow", "alerts" }) do
            local b = "ingame." .. k
            local px, py = getXMLFloat(x, b .. "#x"), getXMLFloat(x, b .. "#y")
            local e = {}
            if type(px) == "number" and type(py) == "number" then e.x, e.y = px, py end
            e.s, e.a, e.m = getXMLFloat(x, b .. "#s"), getXMLFloat(x, b .. "#a"), getXMLString(x, b .. "#m")
            e.w, e.h = getXMLFloat(x, b .. "#w"), getXMLFloat(x, b .. "#h")
            if next(e) ~= nil then out.pos[k] = e end
        end
        return out
    end)
end

local function readNotesXml(path, mapKey)
    if mapKey == nil then return {} end
    return withXml(path, function(x)
        local i = 0
        while i < 500 do
            local base = string.format("notes.map(%d)", i)
            local key = getXMLString(x, base .. "#key")
            if key == nil then break end
            if key == mapKey then
                local out, j = {}, 0
                while j < 2000 do
                    local fp = string.format("%s.field(%d)", base, j)
                    local id = getXMLString(x, fp .. "#id")
                    if id == nil then break end
                    out[id] = getXMLString(x, fp) or ""
                    j = j + 1
                end
                return out
            end
            i = i + 1
        end
        return {}
    end) or {}
end

-- ------------------------------------------------- MES ENGINS + TELEPORTATION ----
-- Liste des engins de ma ferme ou l'on peut monter (pour le compagnon), et ordres "y aller" envoyes par l'application
-- dans modSettings/FS25_StreamDashboard/cmd.xml : <cmd id="..." kind="field|vehicle" target="..."/>.
-- Le mod lit ce fichier chaque seconde, execute un ordre nouveau une seule fois, et repond dans data.json (cmdAck).
-- Fonctions du jeu utilisees (FS25) : g_localPlayer:teleportTo, :leaveVehicle, :requestToEnterVehicle,
-- vehicle:getIsEnterableFromMenu / getIsControlled / getControllerName / getUniqueId.

local function localVehicle()
    local v = g_localPlayer ~= nil and tryCall(g_localPlayer, "getCurrentVehicle") or nil
    if type(v) == "table" then return v end
    return getControlledVehicle(g_currentMission)
end

local function allVehicles()
    local m = g_currentMission
    local vs = m ~= nil and (m.vehicleSystem ~= nil and m.vehicleSystem.vehicles or m.vehicles) or nil
    if type(vs) ~= "table" then return {} end
    return vs
end

local function vehicleKey(v)
    local id = tryCall(v, "getUniqueId")
    if id ~= nil then return tostring(id) end
    if v.rootNode ~= nil then return "n" .. tostring(v.rootNode) end
    return nil
end

local function isMyEnterable(v, mine)
    if type(v) ~= "table" or v.spec_enterable == nil or v.spec_locomotive ~= nil then return false end
    if v.spec_enterable.canBeEnteredFromMenu == false then return false end
    local owner = tryCall(v, "getOwnerFarmId")
    return mine ~= nil and owner == mine
end

-- engins de ma ferme : { id, n (nom), b (marque), fuel %, cond %, x, z, occ (nom du conducteur), me }
-- 1.4.4 : texte de la plaque d'immatriculation (specialisation licensePlates du jeu), ou nil
local function plateText(v)
    local ok, txt = pcall(function()
        local spec = v.spec_licensePlates
        local data = spec ~= nil and spec.licensePlateData or nil
        local chars = data ~= nil and data.characters or nil
        if type(chars) == "table" then
            local t = {}
            for _, c in ipairs(chars) do if type(c) == "string" then table.insert(t, c) end end
            return table.concat(t, "")
        elseif type(chars) == "string" then
            return chars
        end
        return nil
    end)
    if not ok or type(txt) ~= "string" then return nil end
    txt = txt:gsub("_", " "):gsub("^%s+", ""):gsub("%s+$", "")
    if txt == "" then return nil end
    return txt
end

function StreamDashboard:collectFarmVehicles()
    local mine = myFarmId()
    local list, json = {}, {}
    local current = localVehicle()
    for _, v in pairs(allVehicles()) do
        if #list >= 150 then break end
        local ok = pcall(function()
            if not isMyEnterable(v, mine) then return end
            local id = vehicleKey(v)
            if id == nil then return end
            local item = { id = id, n = getVehicleName(v) }
            local brand = getBrandTitle(getStoreItem(v))
            if brand ~= nil and brand ~= "" then item.b = brand end
            local lvl, cap = getFuel(v)
            if lvl ~= nil and cap ~= nil and cap > 0 then item.fuel = math.floor(lvl / cap * 100 + 0.5) end
            local cond = getConditionPercent(v)
            if type(cond) == "number" then item.cond = math.floor(cond + 0.5) end
            local x, z = getRootPosition(v)
            if x ~= nil then item.x = math.floor(x * 10 + 0.5) / 10; item.z = math.floor(z * 10 + 0.5) / 10 end
            if v == current then
                item.me = true
            elseif tryCall(v, "getIsControlled") == true then
                local who = tryCall(v, "getControllerName")
                item.occ = (type(who) == "string" and who ~= "") and who or "?"
            end
            local cat = storeCategory(v)
            if cat ~= nil then item.c = cat end
            local plate = plateText(v)                                         -- 1.4.4 : texte de la plaque
            if plate ~= nil then item.pl = plate end
            -- 1.4.4 : outils attelés (aussi pour un engin garé ; demande de Luxo)
            local tl = toolsOf(v, true)
            if tl[1] ~= nil then item.img = tl[1].img; item.xml = tl[1].xml; item.mod = tl[1].mod end   -- photo de l'engin
            if #tl > 1 then
                local enc = {}
                for i = 2, #tl do
                    local t = { n = tl[i].n, img = tl[i].img, xml = tl[i].xml, mod = tl[i].mod }
                    if tl[i].f ~= nil then t.f = tl[i].f; t.ft = tl[i].ft end
                    table.insert(enc, jsonObject(t))
                end
                item.t = raw("[" .. table.concat(enc, ",") .. "]")
            end
            table.insert(list, item)
        end)
    end
    table.sort(list, function(a, b) return tostring(a.n) < tostring(b.n) end)
    for _, it in ipairs(list) do table.insert(json, jsonObject(it)) end
    self.farmVehiclesJson = json
end


-- Lieux de ma ferme (pour le compagnon) : la maison (point d'apparition de la ferme) + mes batiments utiles
-- (ceux qui ont un repere sur la carte du jeu, ou animaux / silo / production / vente). Calcule toutes les 10 s.
local function nodeXYZ(node)
    if node == nil or getWorldTranslation == nil then return nil end
    local ok, x, y, z = pcall(getWorldTranslation, node)
    if ok and type(x) == "number" and type(z) == "number" then return x, y, z end
    return nil
end

local function homePosition()
    local mine = myFarmId()
    local node = nil
    if g_farmManager ~= nil and g_farmManager.getSpawnPoint ~= nil and mine ~= nil then
        local ok, n = pcall(g_farmManager.getSpawnPoint, g_farmManager, mine)
        if ok then node = n end
    end
    if node == nil then node = g_mission00StartPoint end
    local x, _, z = nodeXYZ(node)
    return x, z
end

local function allPlaceables()
    local m = g_currentMission
    local ps = m ~= nil and m.placeableSystem ~= nil and m.placeableSystem.placeables or nil
    if type(ps) ~= "table" then return {} end
    return ps
end

local function placeableKey(p)
    local id = tryCall(p, "getUniqueId")
    if id ~= nil then return tostring(id) end
    if p.rootNode ~= nil then return "p" .. tostring(p.rootNode) end
    return nil
end

-- position (repere de la carte, point de teleportation du jeu s'il existe, sinon le noeud du batiment)
local function placeableSpot(p)
    local tx, tz, mx, mz
    local spec = p.spec_hotspots
    local hs = spec ~= nil and type(spec.mapHotspots) == "table" and spec.mapHotspots[1] or nil
    if type(hs) == "table" then
        local ok, x, y, z = pcall(function() return hs:getTeleportWorldPosition() end)
        if ok and type(x) == "number" and type(z) == "number" then tx, tz = x, z end
        local ok2, a, b, c = pcall(function() return hs:getWorldPosition() end)
        if ok2 and type(a) == "number" then
            if type(c) == "number" then mx, mz = a, c elseif type(b) == "number" then mx, mz = a, b end
        end
    end
    local rx, _, rz = nodeXYZ(p.rootNode)
    mx, mz = mx or rx, mz or rz
    return mx, mz, tx or mx, tz or mz
end

local function placeableKind(p)
    if p.spec_husbandry ~= nil or p.spec_husbandryAnimals ~= nil then return "animals" end
    if p.spec_sellingStation ~= nil and p.spec_silo == nil then return "sell" end
    if p.spec_silo ~= nil or p.spec_bunkerSilo ~= nil or p.spec_siloExtension ~= nil then return "silo" end
    if p.spec_productionPoint ~= nil then return "prod" end
    if p.spec_buyingStation ~= nil then return "sell" end
    if p.spec_greenhouse ~= nil then return "prod" end
    return "building"
end

-- contenu d'un silo : { {t = nom du produit, l = litres}, ... } (les plus gros d'abord, 8 max)
local function siloContents(p)
    local spec = p.spec_silo
    if spec == nil or type(spec.storages) ~= "table" then return nil end
    local sums, seen = {}, {}
    for _, st in ipairs(spec.storages) do
        if type(st) == "table" and not seen[st] and type(st.fillLevels) == "table" then
            seen[st] = true
            for ft, lvl in pairs(st.fillLevels) do
                if type(lvl) == "number" and lvl >= 1 then sums[ft] = (sums[ft] or 0) + lvl end
            end
        end
    end
    local list = {}
    for ft, lvl in pairs(sums) do
        local info = getFillTypeInfo(ft)
        table.insert(list, { t = info ~= nil and (info.title or info.name) or tostring(ft), l = math.floor(lvl + 0.5), ft = ft })
    end
    table.sort(list, function(a, b) return a.l > b.l end)
    while #list > 8 do table.remove(list) end
    return list
end

local function ftTitle(ft)
    local info = getFillTypeInfo(ft)
    return info ~= nil and (info.title or info.name) or tostring(ft)
end
local function round(v) return math.floor((v or 0) + 0.5) end
local function numSp(v)
    local str = tostring(round(v)):reverse():gsub("(%d%d%d)", "%1 "):reverse()
    return (str:gsub("^ ", ""))
end

-- Batiment d'elevage : animaux, nourriture, conditions du jeu (eau, paille, proprete, productivite...).
-- d = { an = nombre, max = places, food = litres, foodCap = capacite, c = { {t = titre, r = %, inv = vrai si "plus c'est bas mieux c'est"} } }
local function husbandryDetails(p)
    if p.spec_husbandryAnimals == nil and p.spec_husbandry == nil then return nil end
    local d = {}
    local n, mx = tryCall(p, "getNumOfAnimals"), tryCall(p, "getMaxNumOfAnimals")
    if type(n) == "number" then d.an = n end
    if type(mx) == "number" then d.max = mx end
    local food, cap = tryCall(p, "getTotalFood"), tryCall(p, "getFoodCapacity")
    if type(food) == "number" then d.food = round(food) end
    if type(cap) == "number" and cap > 0 then d.foodCap = round(cap) end
    local infos = tryCall(p, "getConditionInfos")
    if type(infos) == "table" then
        d.c = {}
        for _, info in ipairs(infos) do
            if type(info) == "table" and type(info.ratio) == "number" and #d.c < 8 then
                table.insert(d.c, { t = tostring(info.title or "?"), r = round(info.ratio * 100), inv = info.invertedBar == true or nil })
            end
        end
    end
    return d
end

-- Production : en marche ?, entrees et sorties (litres / capacite), ce qui manque.
local PROD_ST = { running = 1, missing = 2, full = 3 }
local function prodStatusIds()
    local t = ProductionPoint ~= nil and ProductionPoint.PROD_STATUS or nil
    if type(t) == "table" then
        return t.RUNNING or PROD_ST.running, t.MISSING_INPUTS or PROD_ST.missing, t.NO_OUTPUT_SPACE or PROD_ST.full
    end
    return PROD_ST.running, PROD_ST.missing, PROD_ST.full
end
local function productionDetails(p)
    local spec = p.spec_productionPoint
    local pp = spec ~= nil and spec.productionPoint or nil
    if pp == nil then return nil end
    local RUN, MISS, FULL = prodStatusIds()
    local d = { inp = {}, out = {}, run = 0, miss = 0, full = 0, n = 0 }
    local st = pp.storage
    local function lv(ft)
        local l = st ~= nil and tryCall(st, "getFillLevel", ft) or nil
        local c = st ~= nil and tryCall(st, "getCapacity", ft) or nil
        return type(l) == "number" and round(l) or 0, type(c) == "number" and round(c) or nil
    end
    for ft in pairs(pp.inputFillTypeIds or {}) do
        if #d.inp < 8 then local l, c = lv(ft); table.insert(d.inp, { t = ftTitle(ft), l = l, c = c, ft = ft }) end
    end
    for ft in pairs(pp.outputFillTypeIds or {}) do
        if #d.out < 6 then local l, c = lv(ft); table.insert(d.out, { t = ftTitle(ft), l = l, c = c, ft = ft }) end
    end
    for _, prod in ipairs(pp.productions or {}) do
        local enabled = true
        if pp.getIsProductionEnabled ~= nil and prod.id ~= nil then
            local ok, e = pcall(pp.getIsProductionEnabled, pp, prod.id)
            if ok then enabled = e == true end
        end
        if enabled then
            d.n = d.n + 1
            if prod.status == RUN then d.run = d.run + 1
            elseif prod.status == MISS then d.miss = d.miss + 1
            elseif prod.status == FULL then d.full = d.full + 1 end
        end
    end
    table.sort(d.inp, function(a, b) return a.t < b.t end)
    return d
end

local function encList(list, keep)
    local enc = {}
    for _, it in ipairs(list) do
        local o = {}
        for _, k in ipairs(keep) do o[k] = it[k] end
        table.insert(enc, jsonObject(o))
    end
    return raw("[" .. table.concat(enc, ",") .. "]")
end

local function isUsefulPlaceable(p, mine)
    if type(p) ~= "table" or p.spec_fence ~= nil then return false end
    if p.spec_sellingStation ~= nil then return true end              -- points de vente : tous (publics ou a moi)
    if mine == nil or tryCall(p, "getOwnerFarmId") ~= mine then return false end
    local spec = p.spec_hotspots
    if spec ~= nil and type(spec.mapHotspots) == "table" and #spec.mapHotspots > 0 then return true end
    return placeableKind(p) ~= "building"
end

function StreamDashboard:collectPlaces()
    local mine = myFarmId()
    local json = {}
    local stock = {}                                                    -- produits que j'ai (silos + productions) : alerte prix
    local hx, hz = homePosition()
    if hx ~= nil then table.insert(json, jsonObject({ id = "home", k = "home", x = math.floor(hx + 0.5), z = math.floor(hz + 0.5) })) end
    local n = 0
    for _, p in pairs(allPlaceables()) do
        if n >= 150 then break end
        pcall(function()
            if not isUsefulPlaceable(p, mine) then return end
            local id = placeableKey(p)
            local mx, mz = placeableSpot(p)
            if id == nil or mx == nil then return end
            local name = tryCall(p, "getName")
            local kind = placeableKind(p)
            local item = { id = id, k = kind, n = type(name) == "string" and name or nil, x = math.floor(mx + 0.5), z = math.floor(mz + 0.5) }
            if tryCall(p, "getOwnerFarmId") ~= mine then item.pub = true end
            if kind == "silo" then
                local c = siloContents(p)
                if c ~= nil then
                    item.fill = encList(c, { "t", "l" })
                    for _, it in ipairs(c) do stock[it.ft] = (stock[it.ft] or 0) + it.l end
                end
            end
            if not item.pub then
                local okH, h = pcall(husbandryDetails, p)
                if okH and h ~= nil then
                    item.an, item.max, item.food, item.foodCap = h.an, h.max, h.food, h.foodCap
                    if h.c ~= nil then item.cond = encList(h.c, { "t", "r", "inv" }) end
                    self:placeAlertsAnimals(id, item.n or "?", h)
                end
                local okP, pd = pcall(productionDetails, p)
                if okP and pd ~= nil then
                    item.inp = encList(pd.inp, { "t", "l", "c" })
                    item.out = encList(pd.out, { "t", "l", "c" })
                    item.st = (pd.n == 0 and "off") or (pd.run > 0 and "run") or (pd.miss > 0 and "miss") or (pd.full > 0 and "full") or "off"
                    self:placeAlertsProduction(id, item.n or "?", pd, item.st)
                    for _, it in ipairs(pd.out) do stock[it.ft] = (stock[it.ft] or 0) + it.l end
                end
            end
            table.insert(json, jsonObject(item))
            n = n + 1
        end)
    end
    self.placesJson = json
    pcall(self.priceAlerts, self, stock)
    self.placesSeenOnce = true                                          -- 1er passage : on note l'etat, sans alerter
end

-- Alertes des batiments (une fois par etat ; re-alerte seulement apres retour a la normale)
function StreamDashboard:placeAlert(key, active, text, kind)
    self.placeAlertState = self.placeAlertState or {}
    local was = self.placeAlertState[key]
    if active and not was and self.placesSeenOnce then self:hudNotify(text, kind) end
    self.placeAlertState[key] = active and true or nil
end

function StreamDashboard:placeAlertsProduction(id, name, pd, st)
    local missing = {}
    for _, it in ipairs(pd.inp) do if (it.l or 0) < 1 then table.insert(missing, it.t) end end
    local ms = #missing > 0 and (" : " .. T("missing") .. " " .. table.concat(missing, ", ", 1, math.min(#missing, 3))) or ""
    self:placeAlert(id .. "|miss", st == "miss", name .. " " .. T("prodStopped") .. ms, "prod")
    self:placeAlert(id .. "|full", st == "full" or pd.full > 0, name .. " : " .. T("outFull"), "prod")
end

function StreamDashboard:placeAlertsAnimals(id, name, h)
    if (h.an or 0) <= 0 then return end
    if h.food ~= nil and h.foodCap ~= nil then
        self:placeAlert(id .. "|food", h.food / h.foodCap < 0.2, name .. " : " .. T("lowFood"), "anim")
    end
    for _, c in ipairs(h.c or {}) do
        if not c.inv then
            local low = c.r < 20
            local t = string.lower(c.t)
            if t:find("eau", 1, true) or t:find("water", 1, true) or t:find("paille", 1, true) or t:find("straw", 1, true) then
                self:placeAlert(id .. "|" .. c.t, low, name .. " : " .. c.t .. " " .. c.r .. " %", "anim")
            end
        end
    end
end

-- Meilleur mois pour vendre : la courbe de prix du jeu (fillType.economy.factors[mois]) est au plus haut ce mois-ci
function StreamDashboard:priceAlerts(stock)
    local env = g_currentMission ~= nil and g_currentMission.environment or nil
    local period = env ~= nil and (env.currentPeriod or env.currentVisualPeriod) or nil
    if type(period) ~= "number" then return end
    if self.pricePeriod == nil then self.pricePeriod = period; return end
    if period == self.pricePeriod then return end
    self.pricePeriod = period
    local best = {}
    for ft, lvl in pairs(stock) do
        local info = getFillTypeInfo(ft)
        local eco = info ~= nil and info.economy or nil
        local f = eco ~= nil and eco.factors or nil
        if lvl >= 100 and type(f) == "table" and type(f[period]) == "number" then
            local mx = 0
            for _, v in pairs(f) do if type(v) == "number" and v > mx then mx = v end end
            if mx > 0 and f[period] >= mx - 0.0001 then
                local ppl = type(info.pricePerLiter) == "number" and info.pricePerLiter or nil
                table.insert(best, { t = info.title or info.name or "?", l = lvl, p = ppl and round(ppl * f[period] * 1000) or nil })
            end
        end
    end
    table.sort(best, function(a, b) return a.l > b.l end)
    for i = 1, math.min(#best, 3) do
        local b = best[i]
        self:hudNotify(T("bestMonth") .. " " .. b.t .. (b.p and (" (~ " .. numSp(b.p) .. " €/1000 L)") or "") .. " - " .. numSp(b.l) .. " L", "price")
    end
end

local function findPlaceSpot(id)
    if id == "home" then
        local x, z = homePosition()
        return x, z
    end
    for _, p in pairs(allPlaceables()) do
        if type(p) == "table" and placeableKey(p) == id then
            local _, _, tx, tz = placeableSpot(p)
            return tx, tz
        end
    end
    return nil
end

local function findVehicle(id)
    for _, v in pairs(allVehicles()) do
        if type(v) == "table" and vehicleKey(v) == id then return v end
    end
    return nil
end

local function findFieldById(id)
    for _, field in ipairs(allFields()) do
        if tostring(fieldId(field)) == tostring(id) then return field end
    end
    return nil
end

local function terrainY(x, z)
    local m = g_currentMission
    local node = m ~= nil and m.terrainRootNode or g_terrainNode
    if node ~= nil and getTerrainHeightAtWorldPos ~= nil then
        local ok, y = pcall(getTerrainHeightAtWorldPos, node, x, 0, z)
        if ok and type(y) == "number" then return y end
    end
    return nil
end

function StreamDashboard:cmdDone(id, ok, msg)
    self.cmdAck = { id = id, ok = ok, msg = msg }
    print("[StreamDashboard] ordre " .. tostring(id) .. " : " .. (ok and "ok" or "refuse") .. " (" .. tostring(msg) .. ")")
end

-- teleportation a pied (apres etre descendu de l'engin si besoin)
function StreamDashboard:doTeleport(id, x, z)
    local p = g_localPlayer
    local y = terrainY(x, z)
    if p == nil or p.teleportTo == nil or y == nil then return self:cmdDone(id, false, "teleport-unavailable") end
    local ok, err = pcall(p.teleportTo, p, x, y + 0.2, z)
    if ok then self:cmdDone(id, true, "teleported") else self:cmdDone(id, false, "teleport-error: " .. tostring(err)) end
end

function StreamDashboard:runCommand(cmd)
    local id = cmd.id
    local p = g_localPlayer
    if p == nil then return self:cmdDone(id, false, "no-player") end
    if cmd.kind == "field" or cmd.kind == "poi" or cmd.kind == "player" then
        local x, z
        if cmd.kind == "player" then
            -- a cote d'un autre joueur (a 4 m, a cote de son engin s'il conduit)
            local target = nil
            for _, pl in ipairs((collectPlayers(g_currentMission))) do
                local isSelf = (pl == g_localPlayer)
                if not isSelf and playerName(pl, g_currentMission) == cmd.target then target = pl end
            end
            if target == nil then return self:cmdDone(id, false, "player-not-found") end
            local veh = tryCall(target, "getCurrentVehicle") or safeField(target, "currentVehicle")
            local node = (type(veh) == "table" and veh.rootNode) or safeField(target, "rootNode")
            local px, py, pz = nil, nil, nil
            if node ~= nil and getWorldTranslation ~= nil then
                local ok, a, b, c = pcall(getWorldTranslation, node)
                if ok then px, py, pz = a, b, c end
            end
            if type(px) ~= "number" then return self:cmdDone(id, false, "player-no-position") end
            local off = type(veh) == "table" and 6 or 3
            local dx, dz = 1, 0
            if localDirectionToWorld ~= nil and node ~= nil then
                local ok, a, _, c = pcall(localDirectionToWorld, node, 1, 0, 0)          -- sur le cote (pas devant l'engin)
                if ok and type(a) == "number" and (math.abs(a) + math.abs(c)) > 0.01 then dx, dz = a, c end
            end
            x, z = px + dx * off, pz + dz * off
        elseif cmd.kind == "field" then
            local field = findFieldById(cmd.target)
            if field == nil then return self:cmdDone(id, false, "field-not-found") end
            x, z = fieldCenter(field, fieldPolygons(field))
            if type(x) ~= "number" or type(z) ~= "number" then return self:cmdDone(id, false, "field-no-position") end
        else
            x, z = findPlaceSpot(cmd.target)
            if type(x) ~= "number" or type(z) ~= "number" then return self:cmdDone(id, false, "place-not-found") end
        end
        if localVehicle() ~= nil then
            local okL = p.leaveVehicle ~= nil and pcall(p.leaveVehicle, p)
            if not okL then return self:cmdDone(id, false, "leave-error") end
            self.pendingTp = { id = id, x = x, z = z, at = (self.clock or 0) + 600 }   -- on laisse le jeu finir la descente
            return
        end
        return self:doTeleport(id, x, z)
    elseif cmd.kind == "vehicle" then
        local v = findVehicle(cmd.target)
        if v == nil then return self:cmdDone(id, false, "vehicle-not-found") end
        if not isMyEnterable(v, myFarmId()) then return self:cmdDone(id, false, "not-my-vehicle") end
        if v == localVehicle() then return self:cmdDone(id, true, "already-inside") end
        if tryCall(v, "getIsControlled") == true then
            local who = tryCall(v, "getControllerName")
            return self:cmdDone(id, false, "occupied:" .. tostring(who or "?"))
        end
        if v.getIsEnterableFromMenu ~= nil then
            local okE, can = pcall(v.getIsEnterableFromMenu, v)
            if okE and can == false then return self:cmdDone(id, false, "not-enterable") end
        end
        if p.requestToEnterVehicle == nil then return self:cmdDone(id, false, "enter-unavailable") end
        local okR, err = pcall(p.requestToEnterVehicle, p, v)
        if okR then self:cmdDone(id, true, "entered") else self:cmdDone(id, false, "enter-error: " .. tostring(err)) end
    else
        self:cmdDone(id, false, "unknown-command")
    end
end

-- lu chaque seconde : nouvel ordre ? (au 1er passage, l'ordre deja present est ignore : il date d'avant la partie)
function StreamDashboard:checkCommand()
    if self.dataPath == nil then return end
    if self.pendingTp ~= nil and (self.clock or 0) >= self.pendingTp.at then
        local t = self.pendingTp
        self.pendingTp = nil
        if localVehicle() ~= nil then
            self:cmdDone(t.id, false, "still-in-vehicle")
        else
            self:doTeleport(t.id, t.x, t.z)
        end
    end
    local dir = string.gsub(self.dataPath, "data%.json$", "")
    local cmd = withXml(dir .. "cmd.xml", function(x)
        return { id = getXMLString(x, "cmd#id"), kind = getXMLString(x, "cmd#kind"), target = getXMLString(x, "cmd#target") }
    end)
    if cmd == nil or cmd.id == nil then
        self.cmdSeen = self.cmdSeen or "none"
        return
    end
    if self.cmdSeen == nil then self.cmdSeen = cmd.id; return end
    if cmd.id == self.cmdSeen then return end
    self.cmdSeen = cmd.id
    local ok, err = pcall(self.runCommand, self, cmd)
    if not ok then self:cmdDone(cmd.id, false, "error: " .. tostring(err)) end
end

-- relit les reglages et les notes ecrits par l'application (toutes les 3 s)
function StreamDashboard:hudReadFiles()
    if self.dataPath == nil then return end
    if (self.clock or 0) < (self.hudFilesNext or 0) then return end
    self.hudFilesNext = (self.clock or 0) + 3000
    local dir = string.gsub(self.dataPath, "data%.json$", "")
    self.ingame = readIngameXml(dir .. "ingame.xml") or {}
    local key = self.mapInfo ~= nil and (self.mapInfo.mapXml or self.mapInfo.image or self.mapInfo.title) or nil
    self.hudNotes = readNotesXml(dir .. "notes.xml", key)
end

-- alertes champs : appele quand l'etat d'un champ est relu
function StreamDashboard:hudFieldChanged(id, st)
    self.hudPrev = self.hudPrev or {}
    local prev = self.hudPrev[id]
    self.hudPrev[id] = { ready = st.ready == true, wither = st.wither == true }
    if prev == nil then return end                                 -- premiere lecture : reference
    local mine = myFarmId()
    if mine == nil or st.of ~= mine then return end
    local name = st.fn and (" — " .. st.fn) or ""
    local ha = type(st.ha) == "number" and string.format(" · %.1f ha", st.ha):gsub("%.", ",", 1) or ""
    if st.ready and not prev.ready then self:hudNotify(T("field") .. " " .. id .. " " .. T("ready") .. name .. ha, "ready") end
    if st.wither and not prev.wither then self:hudNotify(T("field") .. " " .. id .. " " .. T("withered") .. name, "withered") end
end

-- tableau "a faire" (B), "qui fait quoi" (D), entree de champ (C), alertes remorque pleine (A) : une fois par seconde
function StreamDashboard:hudUpdate(players)
    self:hudReadFiles()
    local s = self.ingame or {}
    local mine = myFarmId()

    -- B : a faire
    local groups = { { "harvest", {} }, { "prep", {} }, { "weed", {} }, { "fert", {} }, { "lime", {} }, { "plow", {} }, { "sow", {} } }
    local byKey = {}
    for _, g in ipairs(groups) do byKey[g[1]] = g[2] end
    for id, st in pairs(self.fieldTbl or {}) do
        if mine ~= nil and st.of == mine then
            if st.ready then table.insert(byKey.harvest, { id, st }) end
            if st.prep then table.insert(byKey.prep, { id, st }) end
            if type(st.ws) == "number" and st.ws > 0 and st.fi and not st.cut and not st.wither and not st.ready then table.insert(byKey.weed, { id, st }) end
            if st.fi and not st.ready and not st.cut and not st.wither and not st.prep and type(st.sp) == "number" and st.sp < 100 then table.insert(byKey.fert, { id, st }) end
            if st.lp == 0 then table.insert(byKey.lime, { id, st }) end
            if st.pp == 0 then table.insert(byKey.plow, { id, st }) end
            if not st.fi or st.cut or st.wither then table.insert(byKey.sow, { id, st }) end
        end
    end
    local colors = { harvest = { 0.91, 0.59, 0.16 }, prep = { 0.85, 0.25, 0.16 }, weed = { 0.56, 0.75, 0.23 }, fert = { 0.42, 0.65, 1 },
                     lime = { 0.31, 0.84, 0.71 }, plow = { 0.65, 0.48, 0.35 }, sow = { 0.37, 0.68, 0.29 } }
    local lines = {}
    for _, g in ipairs(groups) do
        local list = g[2]
        if #list > 0 then
            table.sort(list, function(a, b) return a[1] < b[1] end)
            table.insert(lines, { kind = "group", text = T(g[1]), color = colors[g[1]] })
            for i, it in ipairs(list) do
                if i > 4 then table.insert(lines, { kind = "more", text = string.format(T("more"), #list - 4) }); break end
                local st = it[2]
                local txt = st.fn or ""
                if g[1] == "fert" then txt = (st.fn or "") .. " · " .. T("fertPct") .. " " .. tostring(st.sp) .. " %" end
                if g[1] == "sow" then txt = st.cut and ((st.fn or "") .. " " .. T("cut")) or (st.wither and ((st.fn or "") .. " " .. T("withered")) or T("empty")) end
                local ha = type(st.ha) == "number" and (string.format("%.1f ha", st.ha):gsub("%.", ",", 1)) or nil
                local note = self.hudNotes and self.hudNotes[tostring(it[1])]
                table.insert(lines, { kind = "item", num = tostring(it[1]), text = txt, right = ha, note = note ~= nil })
            end
        end
    end
    self.hudTodo = lines

    -- D : qui fait quoi + A : remorque pleine
    local who = {}
    self.hudTools = self.hudTools or {}
    local seen = {}
    for _, p in ipairs(players or {}) do
        local fid = fieldIdAt(p.x, p.z)
        local work = workOfTools(p.tools)
        local full = nil
        for i, t in ipairs(p.tools or {}) do
            if type(t.f) == "number" then
                local key = (p.name or "?") .. "|" .. i .. "|" .. tostring(t.n)
                seen[key] = true
                local before = self.hudTools[key]
                self.hudTools[key] = t.f
                local excluded = false
                local cat = type(t.c) == "string" and t.c:upper() or ""
                for _, w in ipairs(NO_FULL_ALERT) do if cat:find(w, 1, true) then excluded = true end end
                if not excluded and t.f >= 98 then full = t.f end
                -- 1.4.4 : par defaut, seulement les joueurs de MA ferme (remarque de Luxo : alertes des autres fermes)
                local otherFarm = (s.alertFarm or "mine") == "mine" and not p.self and mine ~= nil
                                  and type(p.farmId) == "number" and p.farmId ~= mine
                if not excluded and not otherFarm and before ~= nil and before < 98 and t.f >= 98 then
                    local label = cat:find("HARVEST", 1, true) and T("fullH") or T("full")
                    self:hudNotify(label .. " — " .. tostring(p.name) .. " (" .. tostring(t.n) .. (t.ft and (" · " .. t.ft) or "") .. ")", "full")
                end
            end
        end
        table.insert(who, { name = p.name or "?", self = p.self == true, work = work or (p.vehicle and "" or T("onFoot")),
                            field = fid, full = full, vehicle = p.vehicle, afk = p.afk })
    end
    for k in pairs(self.hudTools) do if not seen[k] then self.hudTools[k] = nil end end
    self.hudWho = who

    -- C : entree dans un champ (joueur local)
    local fi = self.fieldInfo
    local num = (fi ~= nil and fi.onField and type(fi.number) == "number") and fi.number or nil
    if num ~= self.hudLastField then
        self.hudLastField = num
        if num ~= nil and s.field ~= false then
            local st = (self.fieldTbl or {})[num] or {}
            local title = T("field") .. " " .. num .. ((fi.fruit or st.fn) and (" · " .. (fi.fruit or st.fn)) or "")
            local state = st.ready and T("ready") or (st.wither and T("withered") or (st.cut and T("cut") or
                ((type(fi.growthPct) == "number" or type(st.gp) == "number") and (T("growth") .. " " .. math.floor((fi.growthPct or st.gp) + 0.5) .. " %") or nil)))
            local parts = {}
            local owner = fi.owner or st.on
            if fi.ownerFarmId == 0 or st.of == 0 then owner = T("forSale") end
            if owner then table.insert(parts, owner) end
            local ha = fi.areaHa or st.ha
            if type(ha) == "number" then table.insert(parts, (string.format("%.2f ha", ha):gsub("%.", ",", 1))) end
            if type(st.sp) == "number" then table.insert(parts, T("fertPct") .. " " .. st.sp .. " %") end
            if st.lp == 0 then table.insert(parts, T("toLime")) end
            if st.pp == 0 then table.insert(parts, T("toPlow")) end
            self.hudField = { title = title, state = state, ready = st.ready == true, sub = table.concat(parts, " · "),
                              note = self.hudNotes and self.hudNotes[tostring(num)],
                              untilClock = (self.clock or 0) + 1000 * ((type(s.fieldSec) == "number" and math.max(2, math.min(s.fieldSec, 60))) or 7) }
        end
    end
end

-- Touche "afficher / masquer les blocs" : vraie commande du jeu (SD_TOGGLE, declaree dans modDesc.xml, F9 par defaut).
-- Elle apparait dans Options > Commandes et chaque joueur peut la changer. (Alt+T ouvrait aussi le chat : T = chat.)
-- Enregistree a chaque fois que le jeu enregistre les commandes du joueur (a pied et en vehicule).
function StreamDashboard:onToggleHud()
    self.hudOpen = not self.hudOpen
end

local function sdRegisterToggle()
    if g_inputBinding == nil or InputAction == nil or InputAction.SD_TOGGLE == nil then return end
    local ok, okReg, eventId = pcall(g_inputBinding.registerActionEvent, g_inputBinding, InputAction.SD_TOGGLE,
        StreamDashboard, StreamDashboard.onToggleHud, false, true, false, true, nil, true)
    if ok and okReg and eventId ~= nil then
        pcall(g_inputBinding.setActionEventTextVisibility, g_inputBinding, eventId, false)
    end
    if not StreamDashboard.toggleLogged then
        StreamDashboard.toggleLogged = true
        print("[StreamDashboard] touche des blocs (SD_TOGGLE) : " .. ((ok and okReg) and "enregistree" or "non enregistree"))
    end
end

if PlayerInputComponent ~= nil and PlayerInputComponent.registerGlobalPlayerActionEvents ~= nil and Utils ~= nil and Utils.appendedFunction ~= nil then
    PlayerInputComponent.registerGlobalPlayerActionEvents = Utils.appendedFunction(PlayerInputComponent.registerGlobalPlayerActionEvents,
        function() pcall(sdRegisterToggle) end)
end

-- dessin -----------------------------------------------------------------------------
-- Style des blocs = celui du stream : fond vert tres fonce, petits titres gris en majuscules, valeurs blanches,
-- barres de couleur, pastilles arrondies. Le jeu ne dessine que des rectangles : coins arrondis, ronds et icones
-- meteo sont faits de fines bandes (en pixels entiers, sans chevauchement, pour garder une transparence uniforme).
local COL = {
    bg = { 0.086, 0.129, 0.106 }, card = { 0.11, 0.165, 0.133 }, chip = { 0.05, 0.08, 0.063 },
    text = { 0.95, 0.97, 0.95 }, muted = { 0.64, 0.70, 0.66 }, green = { 0.56, 0.89, 0.37 },
    amber = { 0.91, 0.68, 0.32 }, red = { 0.94, 0.42, 0.35 }, blue = { 0.50, 0.71, 1.0 }, dark = { 0.05, 0.08, 0.063 },
    cloud = { 0.81, 0.85, 0.83 }, cloudDark = { 0.58, 0.63, 0.61 }, sun = { 0.96, 0.77, 0.26 }, white = { 0.95, 0.96, 0.97 },
}
local function scr()
    local sw = (type(g_screenWidth) == "number" and g_screenWidth > 0) and g_screenWidth or 1920
    local sh = (type(g_screenHeight) == "number" and g_screenHeight > 0) and g_screenHeight or 1080
    return sw, sh
end
-- largeur "16:9" -> fraction de l'ecran reel (sur un ecran ultra-large, un bloc garde la meme largeur en pixels)
local function wRef(w)
    local sw, sh = scr()
    return w * (16 / 9) * sh / sw
end
-- rectangle arrondi de couleur (radiusPx en pixels d'un ecran 1080p ; tres grand rayon = rond)
local function hRound(x, y, w, h, col, al, radiusPx)
    if drawFilledRect == nil then return end
    local r, g, b = col[1], col[2], col[3]
    local sw, sh = scr()
    local X0, Y0 = math.floor(x * sw + 0.5), math.floor(y * sh + 0.5)
    local X1, Y1 = math.floor((x + w) * sw + 0.5), math.floor((y + h) * sh + 0.5)
    local W, H = X1 - X0, Y1 - Y0
    local rp = math.floor((radiusPx or 10) * sh / 1080 + 0.5)
    rp = math.min(rp, math.floor(W / 2), math.floor(H / 2))
    local function rect(px, py, pw, ph)
        if pw > 0 and ph > 0 then pcall(drawFilledRect, px / sw, py / sh, pw / sw, ph / sh, r, g, b, al) end
    end
    if rp < 2 then rect(X0, Y0, W, H); return end
    rect(X0, Y0 + rp, W, H - 2 * rp)                                  -- bande du milieu
    for i = 0, rp - 1 do                                              -- une ligne de pixels par etage de coin
        local dy = rp - i - 0.5
        local inset = math.floor(rp - math.sqrt(math.max(0, rp * rp - dy * dy)) + 0.5)
        rect(X0 + inset, Y0 + i, W - 2 * inset, 1)                    -- bas
        rect(X0 + inset, Y1 - 1 - i, W - 2 * inset, 1)                -- haut
    end
end
local function hBox(x, y, w, h, a, radiusPx) hRound(x, y, w, h, COL.bg, a or 0.88, radiusPx) end
-- rond : centre (cx, cy) en fraction d'ecran, rayon en fraction de la HAUTEUR
local function hCircle(cx, cy, r, col, al)
    local sw, sh = scr()
    local rw = r * sh / sw
    hRound(cx - rw, cy - r, rw * 2, r * 2, col, al or 1, 9999)
end
local function hRect(x, y, w, h, col, al)
    if drawFilledRect ~= nil then pcall(drawFilledRect, x, y, w, h, col[1], col[2], col[3], al or 1) end
end
local function hText(x, y, size, text, col, bold, align)
    col = col or COL.text
    setTextBold(bold == true)
    setTextColor(col[1], col[2], col[3], 1)
    if RenderText ~= nil then setTextAlignment(align or RenderText.ALIGN_LEFT) end
    renderText(x, y, size, tostring(text))
end
local function hWidth(size, text)
    if getTextWidth ~= nil then
        local ok, w = pcall(getTextWidth, size, tostring(text))
        if ok and type(w) == "number" then return w end
    end
    return #tostring(text) * size * 0.5
end
local function hReset()
    setTextBold(false); setTextColor(1, 1, 1, 1)
    if RenderText ~= nil then setTextAlignment(RenderText.ALIGN_LEFT) end
end
local function hClip(text, size, maxW)
    text = tostring(text or "")
    if maxW <= 0 then return "" end
    if hWidth(size, text) <= maxW then return text end
    while #text > 1 and hWidth(size, text .. "…") > maxW do
        text = text:sub(1, -2)
        while #text > 0 and text:byte(-1) >= 128 and text:byte(-1) < 192 do text = text:sub(1, -2) end   -- pas de lettre coupee en deux
        if #text > 0 and text:byte(-1) >= 192 then text = text:sub(1, -2) end
    end
    return text .. "…"
end
-- pastille (texte dans un fond arrondi), alignee a droite sur xr ; renvoie sa largeur
local function hPill(xr, yMid, size, text, bgCol, fgCol)
    local sw, sh = scr()
    local padX = size * 0.55 * sh / sw
    local tw = hWidth(size, text)
    local w, h = tw + padX * 2, size * 1.45
    hRound(xr - w, yMid - h / 2, w, h, bgCol, 1, 99)
    hText(xr - w + padX, yMid - size * 0.36, size, text, fgCol, true)
    return w
end
local function hBar(x, y, w, h, pct, col)
    hRound(x, y, w, h, { 1, 1, 1 }, 0.10, 99)
    local p = math.max(0, math.min(1, (pct or 0) / 100))
    local sw, sh = scr()
    if p > 0 then hRound(x, y, math.max(w * p, h * 1.2 * sh / sw), h, col or COL.green, 0.95, 99) end
end
local function pctColor(v)
    if type(v) ~= "number" then return COL.muted end
    if v < 34 then return COL.red elseif v < 67 then return COL.amber end
    return COL.green
end

-- icones meteo (centre cx, cy ; s = taille en fraction de la hauteur d'ecran)
local function hCloud(cx, cy, s, col)
    local sw, sh = scr()
    local k = sh / sw
    hCircle(cx - 0.17 * s * k, cy - 0.02 * s, 0.17 * s, col)
    hCircle(cx + 0.04 * s * k, cy + 0.07 * s, 0.23 * s, col)
    hCircle(cx + 0.22 * s * k, cy - 0.04 * s, 0.15 * s, col)
    hRound(cx - 0.30 * s * k, cy - 0.19 * s, 0.62 * s * k, 0.18 * s, col, 1, 99)
end
local function hWeatherIcon(cx, cy, s, kind)
    local sw, sh = scr()
    local k = sh / sw
    kind = tostring(kind or "")
    if kind == "SUN" or kind == "CLEAR" then
        hCircle(cx, cy, 0.27 * s, COL.sun)
    elseif kind == "PARTLY" or kind == "SUNNY_CLOUDY" then
        hCircle(cx - 0.12 * s * k, cy + 0.12 * s, 0.2 * s, COL.sun)
        hCloud(cx + 0.06 * s * k, cy - 0.06 * s, s * 0.85, COL.white)
    elseif kind == "RAIN" or kind == "HAIL" or kind == "SNOW" or kind == "THUNDER" then
        hCloud(cx, cy + 0.12 * s, s * 0.9, kind == "THUNDER" and COL.cloudDark or COL.cloud)
        local drops = { -0.18, 0.0, 0.18 }
        for i, dx in ipairs(drops) do
            local x = cx + dx * s * k
            if kind == "RAIN" then
                hRect(x - 0.025 * s * k, cy - 0.38 * s - (i % 2) * 0.04 * s, 0.05 * s * k, 0.16 * s, COL.blue)
            elseif kind == "THUNDER" then
                if i == 2 then
                    hRect(x - 0.02 * s * k, cy - 0.30 * s, 0.09 * s * k, 0.12 * s, COL.sun)
                    hRect(x - 0.07 * s * k, cy - 0.42 * s, 0.09 * s * k, 0.12 * s, COL.sun)
                end
            else
                hCircle(x, cy - 0.32 * s - (i % 2) * 0.05 * s, 0.05 * s, COL.white)
            end
        end
    elseif kind == "FOG" then
        for i = 0, 2 do hRound(cx - (0.3 - i * 0.04) * s * k, cy + (0.14 - i * 0.14) * s, (0.6 - i * 0.08) * s * k, 0.07 * s, COL.cloud, 1, 99) end
    else                                                              -- CLOUDY et inconnu
        hCloud(cx, cy, s, COL.cloud)
    end
end

function StreamDashboard:draw()
    if self.serverIdle then return end
    if renderText == nil or setTextColor == nil then return end
    if g_gui ~= nil and g_gui.getIsGuiVisible ~= nil then
        local ok, vis = pcall(g_gui.getIsGuiVisible, g_gui)
        if ok and vis then return end
    end
    local hud = g_currentMission ~= nil and g_currentMission.hud or nil
    if hud ~= nil and hud.getIsVisible ~= nil then
        local ok, vis = pcall(hud.getIsVisible, hud)
        if ok and vis == false then return end                     -- HUD masque (photo, cinematique)
    end
    local ok, err = pcall(self.drawHud, self)
    hReset()
    if not ok and not self.hudDrawErr then
        self.hudDrawErr = true
        print("[StreamDashboard] affichage dans le jeu impossible : " .. tostring(err))
    end
end

-- Blocs du HUD : largeur (taille 1, en fraction d'un ecran 16:9), position par defaut (coin haut-gauche, fraction de
-- l'ecran, y depuis le HAUT), interrupteur par defaut. Chaque bloc a sa taille de texte (s), sa largeur (w) et sa
-- hauteur (h) libres, sa transparence de fond (a) et son mode (m : "key" = avec la touche des blocs, "always" = toujours),
-- reglables dans le compagnon (bouton "En jeu").
local HUD_BLOCKS = {
    todo     = { w = 0.19, x = 0.012, y = 0.20, on = true },
    who      = { w = 0.19, x = nil,   y = 0.20, on = true },          -- nil : colle au bord droit
    field    = { w = 0.26, x = "mid", y = 0.22, on = true },          -- encart d'entree de champ (evenement, pas de mode)
    weather  = { w = 0.24, x = "mid", y = 0.02, on = false },
    fieldnow = { w = 0.19, x = nil,   y = 0.40, on = false },
    alerts   = { w = 0.19, x = nil,   y = 0.60, on = false },
}

-- reglages d'un bloc : visible ?, taille du texte, largeur, hauteur imposee, fond
function StreamDashboard:hudBlock(key)
    local s = self.ingame or {}
    local d = HUD_BLOCKS[key]
    local on = s[key]
    if on == nil then on = d.on end
    if on == false then return nil end
    local e = (s.pos and s.pos[key]) or {}
    if key ~= "field" and (e.m or "key") ~= "always" and not self.hudOpen then return nil end
    local sc = (type(s.scale) == "number" and s.scale or 1) * (type(e.s) == "number" and e.s or 1)
    sc = math.max(0.5, math.min(sc, 2.2))
    local alpha = type(e.a) == "number" and math.max(0, math.min(e.a, 1)) or 0.88
    local w = (type(e.w) == "number" and e.w > 0.02) and e.w or d.w * sc
    local fixedH = (type(e.h) == "number" and e.h > 0.02) and math.min(e.h, 0.95) or nil
    return { sc = sc, alpha = alpha, w = math.min(wRef(w), 0.98), fixedH = fixedH, e = e, d = d }
end

local function hPlace(blk, h)
    local d, e, w = blk.d, blk.e, blk.w
    local x, top
    if type(e.x) == "number" and type(e.y) == "number" then
        x, top = e.x, 1 - e.y
    else
        x = (d.x == nil and (0.988 - w)) or (d.x == "mid" and (0.5 - w / 2)) or d.x
        top = 1 - d.y
    end
    x = math.max(0, math.min(x, 1 - w))
    top = math.max(h, math.min(top, 1))
    return x, top
end

-- panneau : titre (+ indication a droite) puis des lignes { h = hauteur, draw = function(x, yTop, w) }.
-- Si une hauteur est imposee, les lignes qui ne rentrent pas ne sont pas dessinees.
local function hPanel(blk, title, hint, hintCol, rows)
    local sw, sh = scr()
    local sc = blk.sc
    local size = 0.014 * sc
    local pad = 0.0105 * sc
    local padX = pad * sh / sw
    local headH = size * 1.55
    local contentH = 0
    for _, r in ipairs(rows) do contentH = contentH + r.h end
    local h = pad * 2 + headH + contentH
    if blk.fixedH then h = math.max(blk.fixedH, pad * 2 + headH) end
    local x, top = hPlace(blk, h)
    local w = blk.w
    hBox(x, top - h, w, h, blk.alpha, 9 * sc)
    local ty = top - pad - size * 0.82
    hText(x + padX, ty, size * 0.78, hClip(title, size * 0.78, w - padX * 2 - (hint and hWidth(size * 0.78, hint) + padX or 0)), COL.muted, true)
    if hint then hText(x + w - padX, ty, size * 0.78, hint, hintCol or COL.green, true, RenderText.ALIGN_RIGHT) end
    local y = top - pad - headH
    local bottom = top - h + pad * 0.6
    for _, r in ipairs(rows) do
        if y - r.h < bottom - 0.0005 then break end
        pcall(r.draw, x + padX, y, w - padX * 2, size)
        y = y - r.h
    end
end

local function fmtPct(v) return type(v) == "number" and (math.floor(v + 0.5) .. " %") or "—" end
local function fmtNum(v)
    local str = tostring(math.floor((v or 0) + 0.5))
    local out = str:reverse():gsub("(%d%d%d)", "%1 "):reverse()
    return (out:gsub("^ ", ""))
end
local function fmtHa(v) return type(v) == "number" and (string.format("%.1f ha", v):gsub("%.", ",", 1)) or nil end

function StreamDashboard:drawHud()
    local s = self.ingame or {}
    local now = self.clock or 0
    local sw, sh = scr()
    local kx = sh / sw                                                -- pour convertir une distance "hauteur" en largeur
    local base = 0.014 * (type(s.scale) == "number" and s.scale or 1)

    -- A (secours) : bandeau du mod si la notification du jeu n'a pas marche
    if self.hudToast ~= nil and now < self.hudToast.untilClock then
        local w = hWidth(base * 1.15, self.hudToast.text) + base * 2.4 * kx
        hBox(0.5 - w / 2, 0.86, w, base * 2.3, 0.9, 9)
        hText(0.5, 0.86 + base * 0.8, base * 1.15, self.hudToast.text, { 1, 0.85, 0.5 }, true, RenderText.ALIGN_CENTER)
    end

    -- C : entree de champ
    local f = self.hudField
    if f ~= nil and now < f.untilClock then
        local blk = self:hudBlock("field")
        if blk ~= nil then
            local sc = blk.sc
            local size, pad = 0.014 * sc, 0.011 * sc
            local padX = pad * kx
            local w = blk.w
            local h = pad * 2 + size * 1.25 + size * 1.5 + (f.note and size * 1.45 or 0)
            if blk.fixedH then h = math.max(h, blk.fixedH) end
            local x, top = hPlace(blk, h)
            hBox(x, top - h, w, h, blk.alpha, 9 * sc)
            local ty = top - pad - size * 1.05
            local pillW = 0
            if f.state then
                pillW = hPill(x + w - padX, ty + size * 0.42, size * 0.82, f.state, f.ready and COL.amber or COL.card, f.ready and COL.dark or COL.green)
            end
            hText(x + padX, ty, size * 1.25, hClip(f.title, size * 1.25, w - padX * 3 - pillW), COL.text, true)
            ty = ty - size * 1.5
            hText(x + padX, ty, size * 0.88, hClip(f.sub, size * 0.88, w - padX * 2), COL.muted, false)
            if f.note then
                ty = ty - size * 1.45
                hText(x + padX, ty, size * 0.92, hClip("» " .. f.note, size * 0.92, w - padX * 2), { 0.95, 0.93, 0.80 }, false)
            end
        end
    end

    -- B : a faire
    local blk = self:hudBlock("todo")
    if blk ~= nil then
        local rows = {}
        local lines = self.hudTodo or {}
        local sz = 0.014 * blk.sc
        if #lines == 0 then
            rows[1] = { h = sz * 1.5, draw = function(x, y, w, size) hText(x, y - size * 1.05, size, T("nothing"), COL.muted) end }
        end
        for _, l in ipairs(lines) do
            if l.kind == "group" then
                rows[#rows + 1] = { h = sz * 1.55, draw = function(x, y, w, size)
                    hText(x, y - size * 1.15, size * 0.95, l.text, l.color, true)
                end }
            elseif l.kind == "more" then
                rows[#rows + 1] = { h = sz * 1.4, draw = function(x, y, w, size)
                    hText(x + size * 2.4 * kx, y - size * 1.0, size * 0.85, l.text, COL.muted)
                end }
            else
                rows[#rows + 1] = { h = sz * 1.62, draw = function(x, y, w, size)
                    local chipW = math.max(hWidth(size * 0.85, "000"), hWidth(size * 0.85, l.num)) + size * 0.7 * kx
                    local chipH = size * 1.32
                    local mid = y - size * 0.82
                    hRound(x, mid - chipH / 2, chipW, chipH, COL.chip, 1, 4 * blk.sc)
                    hText(x + chipW / 2, mid - size * 0.31, size * 0.85, l.num, COL.text, true, RenderText.ALIGN_CENTER)
                    local rt = l.right
                    local rw = rt and (hWidth(size * 0.9, rt) + size * 0.6 * kx) or 0
                    local tx = x + chipW + size * 0.55 * kx
                    hText(tx, mid - size * 0.36, size, hClip(l.text .. (l.note and "  *" or ""), size, w - (tx - x) - rw), COL.text, true)
                    if rt then hText(x + w, mid - size * 0.33, size * 0.9, rt, COL.muted, false, RenderText.ALIGN_RIGHT) end
                end }
            end
        end
        hPanel(blk, T("todo"), T("key"), COL.green, rows)
    end

    -- D : qui fait quoi (masque quand on joue seul)
    blk = self:hudBlock("who")
    local who = self.hudWho or {}
    if blk ~= nil and #who > 1 then
        local rows = {}
        local sz = 0.014 * blk.sc
        for _, p in ipairs(who) do
            local sub = {}
            if p.field then sub[#sub + 1] = T("field") .. " " .. p.field end
            if p.vehicle then sub[#sub + 1] = p.vehicle end
            local subTxt = table.concat(sub, " · ")
            rows[#rows + 1] = { h = sz * (subTxt ~= "" and 2.75 or 1.75), draw = function(x, y, w, size)
                local mid = y - size * 0.85
                local col = p.afk and COL.muted or (p.self and COL.green or { 0.95, 0.65, 0.36 })
                local r = size * 0.66
                hCircle(x + r * kx, mid, r, col)
                local nm = tostring(p.name or "?")
                local initial = nm:match("^[\1-\127]") or nm:match("^[\192-\255][\128-\191]*") or "?"
                hText(x + r * kx, mid - size * 0.32, size * 0.85, string.upper(initial), COL.dark, true, RenderText.ALIGN_CENTER)
                local work = p.work ~= "" and p.work or nil
                local pillW = 0
                if p.afk then
                    pillW = hPill(x + w, mid, size * 0.78, "AFK · " .. p.afk .. " min", COL.card, COL.muted)
                elseif p.full then
                    pillW = hPill(x + w, mid, size * 0.78, (work and (hClip(work, size * 0.78, w * 0.3) .. " · ") or "") .. p.full .. " %", COL.red, COL.dark)
                elseif work then
                    pillW = hPill(x + w, mid, size * 0.78, hClip(work, size * 0.78, w * 0.45), p.self and COL.green or COL.card, p.self and COL.dark or COL.text)
                end
                local tx = x + r * 2 * kx + size * 0.5 * kx
                local name = p.name .. (p.self and (" (" .. T("me") .. ")") or "")
                hText(tx, mid - size * 0.36, size, hClip(name, size, w - (tx - x) - pillW - size * 0.4 * kx), p.afk and COL.muted or COL.text, true)
                if subTxt ~= "" then
                    hText(tx, mid - size * 1.42, size * 0.82, hClip(subTxt, size * 0.82, w - (tx - x)), COL.muted, false)
                end
            end }
        end
        hPanel(blk, T("who"), nil, nil, rows)
    end

    -- E : previsions meteo (colonnes : moment, icone, temperature si le jeu la donne)
    blk = self:hudBlock("weather")
    if blk ~= nil then
        local g = self.hudGame or {}
        local items, rain, hasTemp = {}, nil, false
        for _, it in ipairs(g.forecast or {}) do
            local when
            if (it.dayOffset or 0) >= 2 then when = string.format(T("inDays"), it.dayOffset)
            elseif (it.dayOffset or 0) == 1 and (it.hours or 0) > 12 then when = T("tomorrow")
            else when = "+" .. math.floor((it.hours or 0) + 0.5) .. "h" end
            local bad = it.type == "RAIN" or it.type == "THUNDER" or it.type == "HAIL" or it.type == "SNOW"
            if bad and rain == nil then rain = when end
            if type(it.temperature) == "number" then hasTemp = true end
            items[#items + 1] = { when = when, type = it.type, temp = it.temperature }
        end
        local sz = 0.014 * blk.sc
        local rows = {}
        if #items == 0 then
            rows[1] = { h = sz * 1.5, draw = function(x, y, w, size) hText(x, y - size * 1.05, size, "—", COL.muted) end }
        else
            rows[1] = { h = sz * (hasTemp and 5.1 or 3.9), draw = function(x, y, w, size)
                local n = #items
                local gap = size * 0.35 * kx
                local cw = (w - gap * (n - 1)) / n
                local ch = size * (hasTemp and 4.8 or 3.6)
                for i, it in ipairs(items) do
                    local cx0 = x + (i - 1) * (cw + gap)
                    hRound(cx0, y - ch, cw, ch, COL.card, 1, 6 * blk.sc)
                    local c = cx0 + cw / 2
                    hText(c, y - size * 1.0, size * 0.78, hClip(it.when, size * 0.78, cw - size * 0.3 * kx), COL.muted, true, RenderText.ALIGN_CENTER)
                    hWeatherIcon(c, y - size * 2.2, size * 2.0, it.type)
                    if hasTemp and type(it.temp) == "number" then
                        hText(c, y - size * 4.1, size * 0.95, math.floor(it.temp + 0.5) .. "°", COL.text, true, RenderText.ALIGN_CENTER)
                    end
                end
            end }
        end
        hPanel(blk, T("weather"), rain and (T("rainAt") .. " " .. rain) or nil, COL.blue, rows)
    end

    -- G : champ actuel (tant qu'on est dessus)
    blk = self:hudBlock("fieldnow")
    local fi = self.fieldInfo
    if blk ~= nil and fi ~= nil and fi.onField and fi.number ~= nil then
        local st = (self.fieldTbl or {})[fi.number] or (self.fieldTbl or {})[tostring(fi.number)] or {}
        local sz = 0.014 * blk.sc
        local rows = {}
        local state = fi.harvestReady and T("ready") or (fi.withered and T("withered")) or (fi.cut and T("cut")) or nil
        local ha = fmtHa(fi.areaHa or st.ha)
        rows[1] = { h = sz * 1.9, draw = function(x, y, w, size)
            local by = y - size * 1.35
            local numTxt = T("num") .. " " .. fi.number
            hText(x, by, size * 1.3, numTxt, COL.text, true)
            local tx = x + hWidth(size * 1.3, numTxt) + size * 0.5 * kx
            local right = state or ha
            local rw = right and (hWidth(size * 0.88, right) + size * 0.5 * kx) or 0
            if fi.fruit then hText(tx, by, size * 0.95, hClip(fi.fruit, size * 0.95, w - (tx - x) - rw), COL.green, true) end
            if right then hText(x + w, by, size * 0.88, right, state and COL.amber or COL.muted, state ~= nil, RenderText.ALIGN_RIGHT) end
        end }
        local function barRow(label, pct, valTxt, col)
            rows[#rows + 1] = { h = sz * 1.5, draw = function(x, y, w, size)
                local by = y - size * 1.05
                local lw = math.max(hWidth(size * 0.88, T("growth")), hWidth(size * 0.88, label)) + size * 0.6 * kx
                hText(x, by, size * 0.88, label, COL.muted, false)
                local vw = hWidth(size * 0.88, "100 %") + size * 0.4 * kx
                hBar(x + lw, by + size * 0.22, w - lw - vw, size * 0.3, pct, col)
                hText(x + w, by, size * 0.88, valTxt, col == COL.green and pct >= 100 and COL.green or COL.text, true, RenderText.ALIGN_RIGHT)
            end }
        end
        if type(fi.growthPct) == "number" and not fi.harvestReady then barRow(T("growth2"), fi.growthPct, fmtPct(fi.growthPct), COL.green) end
        local sp = type(fi.sprayPct) == "number" and fi.sprayPct or st.sp
        local lp = type(fi.limePct) == "number" and fi.limePct or st.lp
        local pp = type(fi.plowPct) == "number" and fi.plowPct or st.pp
        if type(sp) == "number" then barRow(T("fert2"), sp, fmtPct(sp), pctColor(sp)) end
        if type(lp) == "number" then barRow(T("lime3"), lp, lp == 0 and T("toLime") or fmtPct(lp), pctColor(lp)) end
        if type(pp) == "number" then barRow(T("plow2"), pp == 0 and 0 or 100, pp == 0 and T("toPlow") or T("ok"), pp == 0 and COL.red or COL.green) end
        local note = self.hudNotes and self.hudNotes[tostring(fi.number)]
        if note and note ~= "" then
            rows[#rows + 1] = { h = sz * 1.5, draw = function(x, y, w, size)
                hText(x, y - size * 1.05, size * 0.9, hClip("» " .. note, size * 0.9, w), { 0.95, 0.93, 0.80 })
            end }
        end
        hPanel(blk, T("fieldnow"), nil, nil, rows)
    end

    -- H : dernieres alertes
    blk = self:hudBlock("alerts")
    if blk ~= nil then
        local rows = {}
        local sz = 0.014 * blk.sc
        local kinds = { ready = COL.amber, withered = COL.red, full = COL.red, prod = COL.red, anim = COL.amber, price = COL.green }
        local maxAge = (type(s.alertSec) == "number" and math.max(10, math.min(s.alertSec, 600)) or 60) * 1000
        for _, a in ipairs(self.hudAlertLog or {}) do
          if now - (a.at or now) <= maxAge then
            local mins = math.floor((now - (a.at or now)) / 60000)
            local when = mins < 1 and T("now") or string.format(T("ago"), mins)
            rows[#rows + 1] = { h = sz * 2.5, draw = function(x, y, w, size)
                local stripW = math.max(2 / sw, size * 0.2 * kx)
                hRect(x, y - size * 2.2, stripW, size * 2.0, kinds[a.kind or ""] or COL.green)
                local tx = x + stripW + size * 0.55 * kx
                hText(tx, y - size * 0.98, size * 0.9, hClip(a.text, size * 0.9, w - (tx - x)), COL.text, true)
                hText(tx, y - size * 1.95, size * 0.78, when, COL.muted, false)
            end }
          end
        end
        if #rows > 0 then hPanel(blk, T("alerts"), nil, nil, rows) end          -- plus d'alerte recente : bloc cache
    end
end

-- ------------------------------------------------------------- MOD LOOP ----
-- 1.4.4 : serveur dedie (G-Portal...) : le mod ne sert a rien la-bas (rien ne passe par le reseau,
-- seuls les mods des PC des joueurs alimentent l'app) -> veille complete pour ne pas charger le serveur.
-- (vu le 25/10/2026 : data.json + fields.json ecrits sur le serveur de Luxo, lag signale par Gazier)
local function isDedicatedServer()
    local m = g_currentMission
    if m ~= nil and type(m.getIsClient) == "function" then
        local ok, isClient = pcall(m.getIsClient, m)
        if ok and type(isClient) == "boolean" then return not isClient end
    end
    return g_dedicatedServer ~= nil
end

function StreamDashboard:loadMap()
    self.serverIdle = isDedicatedServer()
    if self.serverIdle then
        print("[StreamDashboard] v1.4.4.0 : serveur dedie detecte -> mod en veille (rien a faire ici)")
        return
    end
    self.elapsedMs = 0
    self.clock = 0
    self.fieldElapsed = 0
    self.writeElapsedMs = 0
    self.lastX, self.lastZ = nil, nil
    self.lastVehicle = nil
    self.speedKmh = 0
    self.lastWritten = ""
    self.lastSignature = nil
    self.hudOpen = false                                   -- panneaux "A faire" / "Qui fait quoi" fermes au depart (touche des blocs)
    self.fieldTbl, self.hudPrev, self.hudTools, self.hudSent = {}, {}, {}, {}
    self.hudField, self.hudToast, self.hudLastField, self.hudFilesNext = nil, nil, nil, 0
    self.cmdSeen, self.pendingTp, self.cmdAck, self.farmVehNext, self.farmVehiclesJson = nil, nil, nil, 0, nil
    self.placesNext, self.placesJson = 0, nil
    self.placeAlertState, self.placesSeenOnce, self.pricePeriod, self.alertSeq = {}, false, nil, 0
    self.sessionTag = (os ~= nil and type(os.time) == "function") and os.time() or math.random(1, 1e9)
    local profile = (getUserProfileAppPath and getUserProfileAppPath() or "")
    self.dataPath = profile .. "modSettings/FS25_StreamDashboard/data.json"
    if createFolder ~= nil then
        pcall(createFolder, profile .. "modSettings/FS25_StreamDashboard")
    end
    self:writeData(nil, 0, {})
    local hooks = 0
    pcall(function() hooks = self:installFieldHooks() end)
    print("[StreamDashboard] v1.4.4.0 client telemetry loaded; output: " .. self.dataPath
        .. " | field hooks: " .. tostring(hooks))
end

-- Ecrit fields.json (contours des champs), une fois par partie.
function StreamDashboard:writeFieldShapes()
    if self.dataPath == nil then return end
    local items, sources, n = {}, {}, 0
    for _, field in ipairs(allFields()) do
        local id = fieldId(field)
        local polys, src = fieldPolygons(field)
        local cx, cz = fieldCenter(field, polys)
        if id ~= nil and (polys ~= nil or cx ~= nil) then
            local parts = {}
            for _, p in ipairs(polys or {}) do table.insert(parts, "[" .. table.concat(p, ",") .. "]") end
            table.insert(items, jsonObject({ id = id, cx = cx, cz = cz, polys = raw("[" .. table.concat(parts, ",") .. "]") }))
            n = n + 1
            if src then sources[src] = (sources[src] or 0) + 1 end
        end
        self.fieldObjs[#self.fieldObjs + 1] = { field = field, id = id, cx = cx, cz = cz }
    end
    local srcList = {}
    for k, v in pairs(sources) do table.insert(srcList, k .. "=" .. v) end
    local path = string.gsub(self.dataPath, "data%.json$", "fields.json")
    local file = io.open(path, "w")
    if file ~= nil then
        file:write("{\"fields\":[" .. table.concat(items, ",") .. "],\"source\":" .. jsonString(table.concat(srcList, ",")) .. "}\n")
        file:close()
    end
    self.fieldShapesSrc = table.concat(srcList, ",")
    print(string.format("[StreamDashboard] fields.json : %d champ(s), contours : %s", n, self.fieldShapesSrc ~= "" and self.fieldShapesSrc or "aucun"))
end

-- Met a jour l'etat de quelques champs (tourne en boucle sur tous les champs).
function StreamDashboard:updateFieldStates(count)
    local objs = self.fieldObjs
    if objs == nil or #objs == 0 then return end
    for _ = 1, math.min(count, #objs) do
        self.fieldIdx = (self.fieldIdx or 0) % #objs + 1
        local o = objs[self.fieldIdx]
        if o.id ~= nil then
            local st, src = fieldStateOf(o.field, o.cx, o.cz)
            if st ~= nil then
                st.id = o.id
                self.fieldStates[o.id] = jsonObject(st)
                self.fieldTbl = self.fieldTbl or {}
                self.fieldTbl[o.id] = st
                pcall(self.hudFieldChanged, self, o.id, st)
                self.fieldStateSrc = src
            end
        end
    end
end

function StreamDashboard:deleteMap()
    self.lastVehicle = nil
    self.lastX, self.lastZ = nil, nil
    self.fieldInfo, self.fieldRawSnap, self.fieldCapture = nil, nil, nil
    self.playersJson, self.playersSrc, self.mapInfo = nil, nil, nil
    self.fieldObjs, self.fieldStates, self.fieldIdx, self.fieldShapesDone, self.fieldShapesNext = nil, nil, nil, nil, nil
    self.fieldTbl, self.hudPrev, self.hudTools, self.hudTodo, self.hudWho, self.hudField, self.hudToast = nil, nil, nil, nil, nil, nil, nil
    if not self.serverIdle then pcall(self.writeIdle, self) end
end

-- Fin de partie (retour au menu principal) : on ecrit un fichier "hors partie" pour que le dashboard
-- cesse d'afficher les dernieres infos (vehicule, champ...) de la partie precedente.
function StreamDashboard:writeIdle()
    if self.dataPath == nil then return end
    local updatedAt = ""
    if os ~= nil and type(os.date) == "function" then
        local ok, value = pcall(os.date, "%Y-%m-%d %H:%M:%S")
        if ok and value ~= nil then updatedAt = value end
    end
    local file = io.open(self.dataPath, "w")
    if file ~= nil then
        file:write(jsonObject({ session = false, active = false, updatedAt = updatedAt }) .. "\n")
        file:close()
        self.lastWritten = ""
    end
end

function StreamDashboard:writeData(vehicle, speedKmh, implements, handTool)
    if self.dataPath == nil then return end

    local main
    if vehicle == nil and handTool ~= nil then
        main = describeVehicle(handTool, false)                  -- a pied avec un outil a main : nom / marque / image
        main.handTool = true
    else
        main = describeVehicle(vehicle, true)
        handTool = nil
    end
    local fuelLevel, fuelCapacity = getFuel(vehicle)

    local implementJson = {}
    for _, impl in ipairs(implements) do
        table.insert(implementJson, jsonObject(impl))
    end
    local gameInfo = getGameInfo()
    self.hudGame = { forecast = FORECAST_PLAIN }                  -- bloc "previsions meteo" du HUD

    local updatedAt = ""
    if os ~= nil and type(os.date) == "function" then
        local ok, value = pcall(os.date, "%Y-%m-%d %H:%M:%S")
        if ok and value ~= nil then updatedAt = value end
    end

    local root = {
        updatedAt = updatedAt,
        session = true,
        active = vehicle ~= nil,
        vehicle = main.name,
        handTool = handTool ~= nil or nil,
        speedKmh = math.max(0, speedKmh or 0),
        implements = raw("[" .. table.concat(implementJson, ",") .. "]"),
        vehicleInfo = raw(jsonObject(main)),
        fuelLevel = fuelLevel,
        fuelCapacity = fuelCapacity,
        condition = getConditionPercent(vehicle),
        game = raw(jsonObject(gameInfo)),
        field = self.fieldInfo ~= nil and raw(jsonObject(self.fieldInfo)) or nil,
        fieldRaw = self.fieldRawSnap ~= nil and raw(jsonObject(self.fieldRawSnap)) or nil,
        players = self.playersJson ~= nil and raw("[" .. table.concat(self.playersJson, ",") .. "]") or nil,
        playersSrc = self.playersSrc,
        screenW = (type(g_screenWidth) == "number" and g_screenWidth > 0) and g_screenWidth or nil,     -- format de l'ecran (apercu du compagnon)
        screenH = (type(g_screenHeight) == "number" and g_screenHeight > 0) and g_screenHeight or nil,
        farmVehicles = self.farmVehiclesJson ~= nil and raw("[" .. table.concat(self.farmVehiclesJson, ",") .. "]") or nil,
        cmdAck = self.cmdAck ~= nil and raw(jsonObject(self.cmdAck)) or nil,
        places = self.placesJson ~= nil and raw("[" .. table.concat(self.placesJson, ",") .. "]") or nil,
        gameAlerts = (function()                                                 -- alertes batiments / prix (aussi dans le compagnon)
            local t = {}
            for _, a in ipairs(self.hudAlertLog or {}) do
                if a.kind == "prod" or a.kind == "anim" or a.kind == "price" then
                    table.insert(t, jsonObject({ id = tostring(self.sessionTag) .. "-" .. tostring(a.id), text = a.text, kind = a.kind }))
                end
            end
            return #t > 0 and raw("[" .. table.concat(t, ",") .. "]") or nil
        end)(),
        mapInfo = self.mapInfo ~= nil and raw(jsonObject(self.mapInfo)) or nil,
        fieldStates = self.fieldStates ~= nil and raw("[" .. table.concat((function()
            local t = {}
            for _, v in pairs(self.fieldStates) do table.insert(t, v) end
            return t
        end)(), ",") .. "]") or nil,
        fieldStatesSrc = self.fieldStateSrc,
        fieldShapesSrc = self.fieldShapesSrc,
        gameDir = normalizePath(getAppBasePath ~= nil and getAppBasePath() or nil),
        modsDir = normalizePath(g_modsDirectory),
        userDir = normalizePath(getUserProfileAppPath ~= nil and getUserProfileAppPath() or nil),
    }
    local json = jsonObject(root) .. "\n"

    if json == self.lastWritten then return end
    local file = io.open(self.dataPath, "w")
    if file ~= nil then
        file:write(json)
        file:close()
        self.lastWritten = json
    else
        print("[StreamDashboard] ERROR: cannot write " .. tostring(self.dataPath))
    end
end

function StreamDashboard:update(dt)
    if dt == nil or self.serverIdle then return end
    self.elapsedMs = (self.elapsedMs or 0) + dt
    self.clock = (self.clock or 0) + dt
    self.writeElapsedMs = (self.writeElapsedMs or 0) + dt
    if self.elapsedMs < self.UPDATE_INTERVAL_MS then return end
    local sampleMs = self.elapsedMs
    self.elapsedMs = 0

    local mission = g_currentMission
    local vehicle = getControlledVehicle(mission)
    local implements = {}
    if vehicle ~= nil then
        collectImplements(vehicle, implements, {}, 1)
    end
    local rawSpeed = 0

    if vehicle ~= nil then
        local x, z = getRootPosition(vehicle)
        if vehicle ~= self.lastVehicle then
            self.lastVehicle = vehicle
            self.lastX, self.lastZ = x, z
            self.speedKmh = 0
        elseif x ~= nil and self.lastX ~= nil and self.lastZ ~= nil then
            local dx, dz = x - self.lastX, z - self.lastZ
            local distance = math.sqrt(dx * dx + dz * dz)
            local seconds = math.max(sampleMs / 1000, 0.001)
            rawSpeed = (distance / seconds) * 3.6
            if rawSpeed > 120 then
                rawSpeed = self.speedKmh or 0
            end
            self.speedKmh = (self.speedKmh or 0) * (1 - self.SPEED_SMOOTHING) +
                rawSpeed * self.SPEED_SMOOTHING
            self.lastX, self.lastZ = x, z
        else
            self.lastX, self.lastZ = x, z
            self.speedKmh = 0
        end
    else
        self.lastVehicle = nil
        self.lastX, self.lastZ = nil, nil
        self.speedKmh = 0
    end

    -- champ sous le vehicule (ou le joueur a pied), recalcule environ une fois par seconde
    self.fieldElapsed = (self.fieldElapsed or 0) + sampleMs
    if self.fieldElapsed >= 1000 then
        self.fieldElapsed = 0
        pcall(function()
            local fx, fz
            if vehicle ~= nil then fx, fz = getRootPosition(vehicle) else fx, fz = getPlayerPosition() end
            local fresh = self.fieldCapture ~= nil and (self.clock - (self.fieldSeenClock or -1e9)) <= FIELD_STALE_MS
            local snap = fresh and self.fieldCapture or nil
            self.fieldInfo = buildFieldInfo(fx, fz, snap)
            self.fieldRawSnap = snap
        end)
        pcall(function()
            local playersLua
            self.playersJson, self.playersSrc, playersLua = describePlayers(mission, self.clock)
            local okH, errH = pcall(self.hudUpdate, self, playersLua)
            if not okH and not self.hudUpdErr then self.hudUpdErr = true; print("[StreamDashboard] HUD : " .. tostring(errH)) end
            if self.mapInfo == nil or self.mapInfo.size == nil then self.mapInfo = getMapInfo(mission) end
        end)
        -- ordres "y aller" du compagnon, et liste de mes engins (toutes les 2 s)
        local okC, errC = pcall(self.checkCommand, self)
        if not okC and not self.cmdErr then self.cmdErr = true; print("[StreamDashboard] ordres : " .. tostring(errC)) end
        if (self.clock or 0) >= (self.farmVehNext or 0) then
            self.farmVehNext = (self.clock or 0) + 2000
            local okV, errV = pcall(self.collectFarmVehicles, self)
            if not okV and not self.vehErr then self.vehErr = true; print("[StreamDashboard] engins : " .. tostring(errV)) end
        end
        if (self.clock or 0) >= (self.placesNext or 0) then
            self.placesNext = (self.clock or 0) + 10000
            local okP, errP = pcall(self.collectPlaces, self)
            if not okP and not self.placesErr then self.placesErr = true; print("[StreamDashboard] lieux : " .. tostring(errP)) end
        end
        -- couches de la mini-carte : contours une fois, puis 6 champs par seconde
        pcall(function()
            if not self.fieldShapesDone and g_fieldManager ~= nil and (self.fieldShapesNext or 0) <= self.clock then
                self.fieldShapesNext = self.clock + 10000          -- nouvel essai dans 10 s si aucun champ
                self.fieldObjs, self.fieldStates, self.fieldTbl = {}, {}, {}
                self:writeFieldShapes()
                self.fieldShapesDone = #self.fieldObjs > 0
            end
            self:updateFieldStates(6)
        end)
    end

    if self.writeElapsedMs >= self.WRITE_INTERVAL_MS then
        self.writeElapsedMs = 0
        local handTool, handPath = nil, nil
        if vehicle == nil then
            local ok, tool, path = pcall(getHeldHandTool, mission)
            if ok then handTool, handPath = tool, path end
        end
        self:writeData(vehicle, self.speedKmh or 0, implements, handTool)

        -- Journal : uniquement quand le vehicule / les outils / les images changent.
        local main = describeVehicle(vehicle or handTool)
        if handTool ~= nil then main.name = main.name .. " (outil a main via " .. tostring(handPath) .. ")" end
        local names = {}
        for _, impl in ipairs(implements) do
            table.insert(names, impl.name .. " [" .. tostring(impl.image) .. "]")
        end
        local signature = main.name .. "|" .. tostring(main.image) .. "|" .. table.concat(names, ";")
        if signature ~= self.lastSignature then
            self.lastSignature = signature
            print(string.format("[StreamDashboard] vehicle=%s [%s] | implements=%s",
                main.name, tostring(main.image), table.concat(names, ", ")))
        end
    end
end

-- Points d'entree pour les tests hors du jeu (sans effet en partie).
StreamDashboard.test = { getStatus = getStatus, describeVehicle = describeVehicle, getForecast = getForecast,
    getGameInfo = getGameInfo, buildFieldInfo = buildFieldInfo, snapshotScalars = snapshotScalars,
    farmlandOf = farmlandOf, toolsOf = toolsOf, fieldStateOf = fieldStateOf, describePlayers = describePlayers, jsonDecode = jsonDecode }

addModEventListener(StreamDashboard)
